import { useEffect } from 'react';
import { HashRouter, Navigate, Route, Routes } from 'react-router-dom';
import { DashboardLayout } from './components/layout/DashboardLayout';
import { ProtectedRoute } from './components/layout/ProtectedRoute';
import { LockScreen } from './components/LockScreen';
import { useNetwork } from './hooks/useNetwork';
import { pullCoreTables, startRealtimeSync } from './lib/sync';
import { AccountingPage } from './pages/AccountingPage';
import { ActivityLogsPage } from './pages/ActivityLogsPage';
import { AppointmentsPage } from './pages/AppointmentsPage';
import { BackupPage } from './pages/BackupPage';
import { DashboardPage } from './pages/DashboardPage';
import { EmployeesPage } from './pages/EmployeesPage';
import { InventoryPage } from './pages/InventoryPage';
import { LoginPage } from './pages/LoginPage';
import { NotFoundPage } from './pages/NotFoundPage';
import { PatientsPage } from './pages/PatientsPage';
import { ReportsPage } from './pages/ReportsPage';
import { SearchPage } from './pages/SearchPage';
import { SettingsPage } from './pages/SettingsPage';

function SyncBootstrap() {
  const online = useNetwork();
  useEffect(() => {
    if (online) void pullCoreTables();
  }, [online]);
  useEffect(() => startRealtimeSync(), []);
  return null;
}

export default function App() {
  return (
    <HashRouter>
      <SyncBootstrap />
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route element={<ProtectedRoute module="dashboard" />}>
          <Route element={<DashboardLayout />}>
            <Route index element={<DashboardPage />} />
            <Route element={<ProtectedRoute module="patients" />}><Route path="patients" element={<PatientsPage />} /></Route>
            <Route element={<ProtectedRoute module="appointments" />}><Route path="appointments" element={<AppointmentsPage />} /></Route>
            <Route element={<ProtectedRoute module="financials" />}><Route path="accounting" element={<AccountingPage />} /></Route>
            <Route element={<ProtectedRoute module="inventory" />}><Route path="inventory" element={<InventoryPage />} /></Route>
            <Route element={<ProtectedRoute module="employees" />}><Route path="employees" element={<EmployeesPage />} /></Route>
            <Route element={<ProtectedRoute module="reports" />}><Route path="reports" element={<ReportsPage />} /></Route>
            <Route element={<ProtectedRoute module="search" />}><Route path="search" element={<SearchPage />} /></Route>
            <Route element={<ProtectedRoute module="backup" />}><Route path="backup" element={<BackupPage />} /></Route>
            <Route element={<ProtectedRoute module="activityLogs" />}><Route path="activity-logs" element={<ActivityLogsPage />} /></Route>
            <Route element={<ProtectedRoute module="settings" />}><Route path="settings" element={<SettingsPage />} /></Route>
            <Route path="404" element={<NotFoundPage />} />
            <Route path="*" element={<Navigate to="/404" replace />} />
          </Route>
        </Route>
      </Routes>
      <LockScreen />
    </HashRouter>
  );
}
