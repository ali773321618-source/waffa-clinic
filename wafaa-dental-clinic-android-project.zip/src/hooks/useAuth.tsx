import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import type { ClinicUser } from '../types';
import { hashPassword } from '../lib/crypto';
import { db, seedInitialData } from '../lib/db';
import { pullTable } from '../lib/sync';

interface AuthContextValue {
  user: ClinicUser | null;
  loading: boolean;
  locked: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
  unlock: (password: string) => Promise<void>;
  lock: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);
const SESSION_KEY = 'wafaa-clinic-session-user-id';

function getAutoLockMs() {
  const minutes = Number(import.meta.env.VITE_AUTO_LOCK_MINUTES || '15');
  return Math.max(minutes, 1) * 60 * 1000;
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<ClinicUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [locked, setLocked] = useState(false);

  useEffect(() => {
    let active = true;
    async function boot() {
      await seedInitialData();
      const sessionId = localStorage.getItem(SESSION_KEY);
      if (sessionId) {
        const existing = await db.users.get(sessionId);
        if (existing?.active && !existing.deletedAt && active) setUser(existing);
      }
      if (active) setLoading(false);
    }
    void boot();
    return () => { active = false; };
  }, []);

  useEffect(() => {
    if (!user || locked) return;
    const autoLockMs = getAutoLockMs();
    let timer = window.setTimeout(() => setLocked(true), autoLockMs);
    const reset = () => {
      window.clearTimeout(timer);
      timer = window.setTimeout(() => setLocked(true), autoLockMs);
    };
    ['click', 'touchstart', 'keydown', 'mousemove'].forEach((event) => window.addEventListener(event, reset, { passive: true }));
    return () => {
      window.clearTimeout(timer);
      ['click', 'touchstart', 'keydown', 'mousemove'].forEach((event) => window.removeEventListener(event, reset));
    };
  }, [user, locked]);

  const value = useMemo<AuthContextValue>(() => ({
    user,
    loading,
    locked,
    async login(username: string, password: string) {
      await seedInitialData();
      try {
        if (navigator.onLine) await pullTable('users');
      } catch {
        // Offline-first: login continues using local cached users.
      }
      const normalized = username.trim().toLowerCase();
      const candidate = (await db.users.where('username').equals(normalized).first()) || (await db.users.where('username').equals(username.trim()).first());
      if (!candidate || !candidate.active || candidate.deletedAt) throw new Error('بيانات الدخول غير صحيحة أو الحساب غير مفعل.');
      const passwordHash = await hashPassword(password);
      if (candidate.passwordHash !== passwordHash) throw new Error('بيانات الدخول غير صحيحة.');
      localStorage.setItem(SESSION_KEY, candidate.id);
      setUser(candidate);
      setLocked(false);
    },
    logout() {
      localStorage.removeItem(SESSION_KEY);
      setUser(null);
      setLocked(false);
    },
    async unlock(password: string) {
      if (!user) throw new Error('لا توجد جلسة نشطة.');
      const passwordHash = await hashPassword(password);
      const freshUser = await db.users.get(user.id);
      if (!freshUser || freshUser.passwordHash !== passwordHash) throw new Error('كلمة المرور غير صحيحة.');
      setUser(freshUser);
      setLocked(false);
    },
    lock() {
      setLocked(true);
    }
  }), [loading, locked, user]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
