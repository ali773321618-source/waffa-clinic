import { useState } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { hasAccess, moduleLabels } from '../../config/permissions';
import { useAuth } from '../../hooks/useAuth';
import { useNetwork } from '../../hooks/useNetwork';
import { isSupabaseConfigured } from '../../lib/supabase';
import { classNames } from '../../lib/utils';
import type { AppModule } from '../../types';
import { Button } from '../ui/Button';

const navItems: Array<{ to: string; module: AppModule; label: string; icon: string }> = [
  { to: '/', module: 'dashboard', label: 'لوحة التحكم', icon: '▦' },
  { to: '/patients', module: 'patients', label: 'المرضى', icon: '◉' },
  { to: '/appointments', module: 'appointments', label: 'المواعيد', icon: '◷' },
  { to: '/accounting', module: 'financials', label: 'المحاسبة', icon: 'ر.س' },
  { to: '/inventory', module: 'inventory', label: 'المخزون', icon: '□' },
  { to: '/employees', module: 'employees', label: 'الموظفون', icon: '☷' },
  { to: '/reports', module: 'reports', label: 'التقارير', icon: '▤' },
  { to: '/search', module: 'search', label: 'البحث', icon: '⌕' },
  { to: '/backup', module: 'backup', label: 'النسخ الاحتياطي', icon: '↥' },
  { to: '/activity-logs', module: 'activityLogs', label: 'سجل النشاط', icon: '≡' },
  { to: '/settings', module: 'settings', label: 'الإعدادات', icon: '⚙' }
];

function Sidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { user } = useAuth();
  const allowed = navItems.filter((item) => hasAccess(user, item.module));

  return (
    <>
      <div className={classNames('fixed inset-0 z-30 bg-slate-950/40 transition md:hidden', open ? 'block' : 'hidden')} onClick={onClose} />
      <aside className={classNames('fixed right-0 top-0 z-40 h-full w-72 translate-x-full border-l border-slate-200 bg-white p-4 shadow-xl transition md:static md:z-auto md:block md:w-72 md:translate-x-0 md:shadow-none', open && 'translate-x-0')}>
        <div className="mb-6 rounded-2xl bg-clinic-700 p-4 text-white">
          <p className="text-xs font-bold opacity-80">نظام إدارة العيادة</p>
          <h1 className="mt-1 text-lg font-extrabold">عيادة د. وفاء عبدالكريم</h1>
        </div>
        <nav className="space-y-1">
          {allowed.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              onClick={onClose}
              className={({ isActive }) => classNames(
                'flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-bold transition',
                isActive ? 'bg-clinic-50 text-clinic-800' : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              )}
            >
              <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-slate-100 text-xs">{item.icon}</span>
              {item.label}
            </NavLink>
          ))}
        </nav>
      </aside>
    </>
  );
}

export function DashboardLayout() {
  const [open, setOpen] = useState(false);
  const { user, logout, lock } = useAuth();
  const online = useNetwork();

  return (
    <div className="min-h-screen bg-slate-50" dir="rtl">
      <div className="flex min-h-screen">
        <Sidebar open={open} onClose={() => setOpen(false)} />
        <main className="min-w-0 flex-1">
          <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/90 backdrop-blur">
            <div className="flex items-center justify-between gap-3 px-4 py-3 md:px-6">
              <div className="flex items-center gap-2">
                <Button variant="ghost" className="md:hidden" onClick={() => setOpen(true)}>☰</Button>
                <div>
                  <p className="text-sm font-extrabold text-slate-900">{user?.fullName}</p>
                  <p className="text-xs text-slate-500">{user?.role ? moduleLabels.dashboard : ''} · {online ? 'متصل' : 'أوفلاين'} · {isSupabaseConfigured ? 'Supabase مفعّل' : 'محلي فقط'}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="secondary" onClick={lock}>قفل</Button>
                <Button variant="ghost" onClick={logout}>خروج</Button>
              </div>
            </div>
          </header>
          <div className="mx-auto max-w-7xl p-4 md:p-6">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
