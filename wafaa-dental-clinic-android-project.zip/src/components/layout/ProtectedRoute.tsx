import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { hasAccess } from '../../config/permissions';
import { useAuth } from '../../hooks/useAuth';
import type { AppModule, PermissionLevel } from '../../types';
import { Card } from '../ui/Card';

export function ProtectedRoute({ module = 'dashboard', minimum = 'view' }: { module?: AppModule; minimum?: PermissionLevel }) {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) return <div className="flex min-h-screen items-center justify-center bg-slate-50 text-sm font-bold text-slate-600">جاري التحميل...</div>;
  if (!user) return <Navigate to="/login" replace state={{ from: location }} />;
  if (!hasAccess(user, module, minimum)) {
    return (
      <Card className="mx-auto mt-10 max-w-lg text-center">
        <h1 className="text-xl font-extrabold text-red-700">لا تملك صلاحية الوصول</h1>
        <p className="mt-2 text-sm text-slate-500">هذه الصفحة محمية حسب الدور والصلاحيات المخصصة لحسابك.</p>
      </Card>
    );
  }
  return <Outlet />;
}
