import { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { Button } from './ui/Button';
import { Card } from './ui/Card';
import { Field, Input } from './ui/Form';

export function LockScreen() {
  const { locked, user, unlock, logout } = useAuth();
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  if (!locked || !user) return null;

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError('');
    try {
      await unlock(password);
      setPassword('');
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur" dir="rtl">
      <Card className="w-full max-w-sm">
        <div className="mb-4 text-center">
          <div className="mx-auto mb-2 flex h-14 w-14 items-center justify-center rounded-2xl bg-clinic-50 text-2xl">🔒</div>
          <h2 className="text-xl font-extrabold text-slate-900">تم قفل الجلسة</h2>
          <p className="mt-1 text-sm text-slate-500">أدخل كلمة المرور للمتابعة كـ {user.fullName}</p>
        </div>
        <form onSubmit={submit} className="space-y-3">
          <Field label="كلمة المرور">
            <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoFocus />
          </Field>
          {error ? <p className="text-sm font-bold text-red-600">{error}</p> : null}
          <Button className="w-full" type="submit">فتح القفل</Button>
          <Button className="w-full" variant="ghost" type="button" onClick={logout}>تسجيل خروج</Button>
        </form>
      </Card>
    </div>
  );
}
