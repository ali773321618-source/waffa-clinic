import React from 'react';
import { Card } from './ui/Card';

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { error: Error | null }> {
  state = { error: null as Error | null };

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  render() {
    if (this.state.error) {
      return (
        <div className="flex min-h-screen items-center justify-center bg-slate-50 p-4" dir="rtl">
          <Card className="max-w-lg">
            <h1 className="text-xl font-extrabold text-red-700">حدث خطأ في الواجهة</h1>
            <p className="mt-2 text-sm text-slate-600">تم منع الشاشة البيضاء. راجع الخطأ التالي ثم أصلح الإعداد أو البيانات.</p>
            <pre className="mt-4 overflow-auto rounded-xl bg-slate-950 p-3 text-left text-xs text-white">{this.state.error.message}</pre>
            <button className="mt-4 rounded-xl bg-clinic-700 px-4 py-2 text-sm font-bold text-white" onClick={() => location.reload()}>إعادة التحميل</button>
          </Card>
        </div>
      );
    }
    return this.props.children;
  }
}
