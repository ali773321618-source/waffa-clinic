import type { ButtonHTMLAttributes } from 'react';
import { classNames } from '../../lib/utils';

type Variant = 'primary' | 'secondary' | 'danger' | 'ghost';

export function Button({ className, variant = 'primary', ...props }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }) {
  const variants: Record<Variant, string> = {
    primary: 'bg-clinic-700 text-white hover:bg-clinic-900 shadow-sm',
    secondary: 'bg-white text-slate-800 border border-slate-200 hover:bg-slate-50 shadow-sm',
    danger: 'bg-red-600 text-white hover:bg-red-700 shadow-sm',
    ghost: 'bg-transparent text-slate-700 hover:bg-slate-100'
  };
  return (
    <button
      {...props}
      className={classNames(
        'inline-flex min-h-10 items-center justify-center rounded-xl px-4 py-2 text-sm font-bold transition disabled:cursor-not-allowed disabled:opacity-50',
        variants[variant],
        className
      )}
    />
  );
}
