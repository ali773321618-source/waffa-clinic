export function TableWrap({ children }: { children: React.ReactNode }) {
  return <div className="no-scrollbar overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-sm"><table className="min-w-full divide-y divide-slate-100 text-right text-sm">{children}</table></div>;
}

export function Th({ children }: { children: React.ReactNode }) {
  return <th className="whitespace-nowrap px-4 py-3 text-xs font-extrabold text-slate-500">{children}</th>;
}

export function Td({ children }: { children: React.ReactNode }) {
  return <td className="whitespace-nowrap px-4 py-3 align-top text-slate-700">{children}</td>;
}
