import type { InputHTMLAttributes, SelectHTMLAttributes, TextareaHTMLAttributes } from 'react';
import { classNames } from '../../lib/utils';

export function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-bold text-slate-600">{label}</span>
      {children}
    </label>
  );
}

export function Input({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={classNames('w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none transition focus:border-clinic-600 focus:ring-2 focus:ring-clinic-100', className)} />;
}

export function Select({ className, ...props }: SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...props} className={classNames('w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none transition focus:border-clinic-600 focus:ring-2 focus:ring-clinic-100', className)} />;
}

export function Textarea({ className, ...props }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={classNames('w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none transition focus:border-clinic-600 focus:ring-2 focus:ring-clinic-100', className)} />;
}
