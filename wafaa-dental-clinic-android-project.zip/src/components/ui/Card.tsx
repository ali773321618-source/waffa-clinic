import type { HTMLAttributes } from 'react';
import { classNames } from '../../lib/utils';

export function Card({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div {...props} className={classNames('rounded-2xl border border-slate-200 bg-white p-4 shadow-sm', className)} />;
}

export function StatCard({ title, value, hint }: { title: string; value: React.ReactNode; hint?: string }) {
  return (
    <Card>
      <p className="text-xs font-bold text-slate-500">{title}</p>
      <div className="mt-2 text-2xl font-extrabold text-slate-900">{value}</div>
      {hint ? <p className="mt-1 text-xs text-slate-500">{hint}</p> : null}
    </Card>
  );
}
