import { downloadTextFile, escapeHtml } from './utils';

export function exportJson(filename: string, data: unknown) {
  downloadTextFile(filename, JSON.stringify(data, null, 2), 'application/json;charset=utf-8');
}

export function exportExcelHtml(filename: string, sheets: Record<string, Array<Record<string, unknown>>>) {
  const html = `
    <html dir="rtl"><head><meta charset="UTF-8" /></head><body>
    ${Object.entries(sheets).map(([name, rows]) => {
      const columns = Array.from(rows.reduce((set, row) => {
        Object.keys(row).forEach((key) => set.add(key));
        return set;
      }, new Set<string>()));
      return `<h2>${escapeHtml(name)}</h2><table border="1"><thead><tr>${columns.map((c) => `<th>${escapeHtml(c)}</th>`).join('')}</tr></thead><tbody>${rows.map((row) => `<tr>${columns.map((c) => `<td>${escapeHtml(row[c])}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
    }).join('<br/>')}
    </body></html>`;
  downloadTextFile(filename.endsWith('.xls') ? filename : `${filename}.xls`, html, 'application/vnd.ms-excel;charset=utf-8');
}

export function printHtmlReport(title: string, bodyHtml: string) {
  const win = window.open('', '_blank', 'width=900,height=700');
  if (!win) throw new Error('المتصفح منع فتح نافذة الطباعة.');
  win.document.write(`<!doctype html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><title>${escapeHtml(title)}</title><style>body{font-family:Cairo,Tahoma,Arial,sans-serif;padding:24px;color:#0f172a}table{width:100%;border-collapse:collapse;margin:16px 0}th,td{border:1px solid #cbd5e1;padding:8px;text-align:right}th{background:#f1f5f9}.muted{color:#64748b}</style></head><body><h1>${escapeHtml(title)}</h1>${bodyHtml}<script>window.print()</script></body></html>`);
  win.document.close();
}
