const dataEvents = new EventTarget();
export const DATA_CHANGED = 'clinic:data-changed';

export function notifyDataChanged() {
  dataEvents.dispatchEvent(new Event(DATA_CHANGED));
}

export function onDataChanged(listener: () => void) {
  dataEvents.addEventListener(DATA_CHANGED, listener);
  return () => dataEvents.removeEventListener(DATA_CHANGED, listener);
}
