import type { RealtimeChannel } from '@supabase/supabase-js';
import type { EntityTableName, SyncAction, SyncQueueItem } from '../types';
import { db, localTables } from './db';
import { notifyDataChanged } from './events';
import { supabase } from './supabase';
import { nowIso, uid } from './utils';

function getLocalTable(tableName: EntityTableName) {
  return localTables[tableName];
}

export async function queueSync(tableName: EntityTableName, action: SyncAction, payload: unknown, lastError?: string) {
  const now = nowIso();
  const item: SyncQueueItem = {
    id: uid('sync'),
    tableName,
    action,
    payload,
    status: 'pending',
    retries: 0,
    lastError,
    createdAt: now,
    updatedAt: now,
    deletedAt: null
  };
  await db.syncQueue.add(item);
  notifyDataChanged();
}

async function pushToSupabase(tableName: EntityTableName, action: SyncAction, payload: any) {
  if (!supabase) throw new Error('Supabase غير مفعّل. أضف مفاتيح البيئة أولاً.');
  const remote = supabase.from(tableName);
  if (action === 'delete') {
    const { error } = await remote.upsert(payload);
    if (error) throw error;
    return;
  }
  const { error } = await remote.upsert(payload);
  if (error) throw error;
}

export async function upsertLocalFirst<T extends { id: string }>(tableName: EntityTableName, record: T) {
  const table = getLocalTable(tableName) as any;
  await table.put(record);
  notifyDataChanged();

  if (!navigator.onLine || !supabase) {
    await queueSync(tableName, 'upsert', record, !supabase ? 'Supabase غير مهيأ' : 'الجهاز غير متصل');
    return;
  }

  try {
    await pushToSupabase(tableName, 'upsert', record);
  } catch (error) {
    await queueSync(tableName, 'upsert', record, error instanceof Error ? error.message : String(error));
  }
}

export async function softDeleteLocalFirst<T extends { id: string; deletedAt?: string | null; updatedAt: string }>(tableName: EntityTableName, record: T) {
  const payload = { ...record, deletedAt: nowIso(), updatedAt: nowIso() };
  const table = getLocalTable(tableName) as any;
  await table.put(payload);
  notifyDataChanged();

  if (!navigator.onLine || !supabase) {
    await queueSync(tableName, 'delete', payload, !supabase ? 'Supabase غير مهيأ' : 'الجهاز غير متصل');
    return;
  }

  try {
    await pushToSupabase(tableName, 'delete', payload);
  } catch (error) {
    await queueSync(tableName, 'delete', payload, error instanceof Error ? error.message : String(error));
  }
}

export async function processSyncQueue() {
  if (!navigator.onLine || !supabase) return;
  const pending = await db.syncQueue.where('status').equals('pending').sortBy('createdAt');

  for (const item of pending) {
    try {
      await pushToSupabase(item.tableName, item.action, item.payload);
      await db.syncQueue.update(item.id, { status: 'synced', updatedAt: nowIso(), lastError: undefined });
    } catch (error) {
      await db.syncQueue.update(item.id, {
        status: item.retries >= 4 ? 'failed' : 'pending',
        retries: item.retries + 1,
        lastError: error instanceof Error ? error.message : String(error),
        updatedAt: nowIso()
      });
    }
  }
  notifyDataChanged();
}

export async function pullTable(tableName: EntityTableName) {
  if (!supabase || !navigator.onLine) return;
  const { data, error } = await supabase.from(tableName).select('*');
  if (error) throw error;
  if (!data) return;
  const table = getLocalTable(tableName) as any;
  await table.bulkPut(data);
  notifyDataChanged();
}

export async function pullCoreTables() {
  if (!supabase || !navigator.onLine) return;
  const tables: EntityTableName[] = ['users', 'patients', 'appointments', 'transactions', 'employees', 'inventory', 'activityLogs', 'settings'];
  for (const table of tables) {
    try {
      await pullTable(table);
    } catch (error) {
      console.warn(`فشل سحب جدول ${table}`, error);
    }
  }
}

export function startRealtimeSync() {
  const client = supabase;
  if (!client) return () => undefined;
  const channels: RealtimeChannel[] = [];
  const tables: EntityTableName[] = ['users', 'patients', 'appointments', 'transactions', 'employees', 'inventory', 'activityLogs', 'settings'];

  tables.forEach((tableName) => {
    const channel = client
      .channel(`clinic-${tableName}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: tableName }, async (payload) => {
        const table = getLocalTable(tableName) as any;
        if (payload.eventType === 'DELETE') return;
        if (payload.new) {
          await table.put(payload.new);
          notifyDataChanged();
        }
      })
      .subscribe();
    channels.push(channel);
  });

  return () => {
    channels.forEach((channel) => client.removeChannel(channel));
  };
}
