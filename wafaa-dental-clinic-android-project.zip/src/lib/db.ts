import Dexie, { type Table } from 'dexie';
import { makeDefaultPermissions } from '../config/permissions';
import type {
  ActivityLog,
  Appointment,
  ClinicSetting,
  ClinicUser,
  Employee,
  InventoryItem,
  Patient,
  SyncQueueItem,
  Transaction
} from '../types';
import { hashPassword } from './crypto';
import { nowIso, uid } from './utils';

class ClinicDatabase extends Dexie {
  users!: Table<ClinicUser, string>;
  patients!: Table<Patient, string>;
  appointments!: Table<Appointment, string>;
  transactions!: Table<Transaction, string>;
  employees!: Table<Employee, string>;
  inventory!: Table<InventoryItem, string>;
  activityLogs!: Table<ActivityLog, string>;
  syncQueue!: Table<SyncQueueItem, string>;
  settings!: Table<ClinicSetting, string>;

  constructor() {
    super('wafaaDentalClinicDb');

    // STRICT: Dexie Version 1 schema only.
    this.version(1).stores({
      users: 'id, username, role, doctorId, active, deletedAt',
      patients: 'id, fullName, phone, assignedDoctorId, currency, paymentStatus, treatmentCompleted, createdAt, updatedAt, deletedAt',
      appointments: 'id, patientId, doctorId, appointmentAt, status, createdAt, updatedAt, deletedAt',
      transactions: 'id, type, currency, patientId, doctorId, employeeId, date, createdAt, updatedAt, deletedAt',
      employees: 'id, fullName, role, active, currency, createdAt, updatedAt, deletedAt',
      inventory: 'id, name, quantity, minThreshold, createdAt, updatedAt, deletedAt',
      activityLogs: 'id, actorId, module, action, createdAt, updatedAt',
      syncQueue: 'id, tableName, action, status, createdAt, updatedAt',
      settings: 'key'
    });
  }
}

export const db = new ClinicDatabase();

export async function seedInitialData() {
  const count = await db.users.count();
  if (count > 0) return;

  const now = nowIso();
  const doctorId = uid('doctor');
  const users: ClinicUser[] = [
    {
      id: uid('user'),
      fullName: 'مدير النظام',
      username: 'admin',
      passwordHash: await hashPassword('admin123'),
      role: 'admin',
      doctorId: null,
      permissions: makeDefaultPermissions('admin'),
      active: true,
      createdAt: now,
      updatedAt: now,
      deletedAt: null
    },
    {
      id: doctorId,
      fullName: 'د. وفاء عبدالكريم',
      username: 'doctor',
      passwordHash: await hashPassword('doctor123'),
      role: 'doctor',
      doctorId,
      permissions: makeDefaultPermissions('doctor'),
      active: true,
      createdAt: now,
      updatedAt: now,
      deletedAt: null
    },
    {
      id: uid('user'),
      fullName: 'الاستقبال',
      username: 'reception',
      passwordHash: await hashPassword('reception123'),
      role: 'receptionist',
      doctorId: null,
      permissions: makeDefaultPermissions('receptionist'),
      active: true,
      createdAt: now,
      updatedAt: now,
      deletedAt: null
    },
    {
      id: uid('user'),
      fullName: 'المحاسب',
      username: 'accountant',
      passwordHash: await hashPassword('accountant123'),
      role: 'accountant',
      doctorId: null,
      permissions: makeDefaultPermissions('accountant'),
      active: true,
      createdAt: now,
      updatedAt: now,
      deletedAt: null
    }
  ];

  await db.users.bulkAdd(users);
  await db.employees.add({
    id: uid('employee'),
    fullName: 'د. وفاء عبدالكريم',
    jobTitle: 'طبيبة أسنان',
    role: 'doctor',
    monthlySalary: 0,
    currency: 'YER',
    active: true,
    createdAt: now,
    updatedAt: now,
    deletedAt: null
  });

  await db.settings.put({ key: 'clinicName', value: import.meta.env.VITE_CLINIC_NAME || 'عيادة د. وفاء عبدالكريم', updatedAt: now });
}

export const localTables = {
  users: db.users,
  patients: db.patients,
  appointments: db.appointments,
  transactions: db.transactions,
  employees: db.employees,
  inventory: db.inventory,
  activityLogs: db.activityLogs,
  settings: db.settings
};
