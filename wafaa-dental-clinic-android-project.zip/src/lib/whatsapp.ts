import type { Patient } from '../types';
import { formatMoney } from './utils';

export function buildPatientWhatsAppMessage(patient: Patient, clinicName = 'عيادة د. وفاء عبدالكريم') {
  return [
    'أهلاً وسهلاً بكم 🌿',
    `نرحب بكم في ${clinicName}`,
    '',
    `اسم المريض: ${patient.fullName}`,
    `الطبيب المسؤول: ${patient.assignedDoctorName || '-'}`,
    `نوع العلاج: ${patient.procedureType}`,
    `إجمالي التكلفة: ${formatMoney(patient.totalCost, patient.currency)}`,
    `المبلغ المدفوع: ${formatMoney(patient.paidAmount, patient.currency)}`,
    `المبلغ المتبقي: ${formatMoney(patient.remainingBalance, patient.currency)}`,
    '',
    'نتمنى لكم دوام الصحة والعافية.'
  ].join('\n');
}

export function makeWhatsAppUrl(phone: string, message: string) {
  const normalizedPhone = phone.replace(/[^0-9+]/g, '').replace(/^00/, '+');
  const phoneForUrl = normalizedPhone.replace('+', '');
  return `https://wa.me/${phoneForUrl}?text=${encodeURIComponent(message)}`;
}
