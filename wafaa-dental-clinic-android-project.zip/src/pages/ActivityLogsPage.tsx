import { PageHeader } from '../components/ui/Page';
import { TableWrap, Td, Th } from '../components/ui/Table';
import { moduleLabels } from '../config/permissions';
import { useAsyncData } from '../hooks/useAsyncData';
import { db } from '../lib/db';
import { formatDateTime } from '../lib/utils';

export function ActivityLogsPage() {
  const { data } = useAsyncData(async () => (await db.activityLogs.toArray()).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 300), []);
  return (
    <div>
      <PageHeader title="سجل النشاط" description="تتبّع العمليات المهمة داخل النظام: إضافة، تعديل، أرشفة، نسخ احتياطي، واستعادة." />
      <TableWrap>
        <thead><tr><Th>الوقت</Th><Th>المستخدم</Th><Th>الوحدة</Th><Th>الإجراء</Th><Th>التفاصيل</Th></tr></thead>
        <tbody className="divide-y divide-slate-100">
          {data?.map((log) => <tr key={log.id}><Td>{formatDateTime(log.createdAt)}</Td><Td>{log.actorName || '-'}</Td><Td>{moduleLabels[log.module]}</Td><Td>{log.action}</Td><Td>{log.details || '-'}</Td></tr>)}
        </tbody>
      </TableWrap>
    </div>
  );
}
