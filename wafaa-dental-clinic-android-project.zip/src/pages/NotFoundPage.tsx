import { Link } from 'react-router-dom';
import { Card } from '../components/ui/Card';

export function NotFoundPage() {
  return (
    <Card className="mx-auto mt-10 max-w-lg text-center">
      <h1 className="text-2xl font-extrabold text-slate-900">الصفحة غير موجودة</h1>
      <p className="mt-2 text-sm text-slate-500">الرابط غير صحيح أو لا تملك صلاحية الوصول.</p>
      <Link className="mt-4 inline-flex rounded-xl bg-clinic-700 px-4 py-2 text-sm font-bold text-white" to="/">العودة للوحة التحكم</Link>
    </Card>
  );
}
