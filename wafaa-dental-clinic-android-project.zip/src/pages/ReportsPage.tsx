import { useMemo, useState } from 'react';
import { Button } from '../components/ui/Button';
import { Card, StatCard } from '../components/ui/Card';
import { Field, Input } from '../components/ui/Form';
import { PageHeader } from '../components/ui/Page';
import { TableWrap, Td, Th } from '../components/ui/Table';
import { useAuth } from '../hooks/useAuth';
import { useAsyncData } from '../hooks/useAsyncData';
import { exportExcelHtml, exportJson, printHtmlReport } from '../lib/exporters';
import { escapeHtml, formatMoney, todayInputValue } from '../lib/utils';
import { getCurrencySummaries, listAppointmentsForUser, listPatientsForUser, listTransactionsForUser } from '../services/repositories';

function inRange(date: string, from: string, to: string) {
  return (!from || date >= from) && (!to || date <= to);
}

export function ReportsPage() {
  const { user } = useAuth();
  const today = todayInputValue();
  const [from, setFrom] = useState(today.slice(0, 8) + '01');
  const [to, setTo] = useState(today);

  const { data } = useAsyncData(async () => {
    if (!user) return null;
    const [patients, appointments, transactions, summaries] = await Promise.all([
      listPatientsForUser(user),
      listAppointmentsForUser(user),
      listTransactionsForUser(user),
      getCurrencySummaries(user)
    ]);
    return { patients, appointments, transactions, summaries };
  }, [user?.id]);

  const report = useMemo(() => {
    const patients = (data?.patients || []).filter((p) => inRange(p.createdAt.slice(0, 10), from, to));
    const appointments = (data?.appointments || []).filter((a) => inRange(a.appointmentAt.slice(0, 10), from, to));
    const transactions = (data?.transactions || []).filter((t) => inRange(t.date, from, to));
    const doctors = patients.reduce<Record<string, { doctor: string; patients: number; paid: number; outstanding: number }>>((acc, p) => {
      const key = p.assignedDoctorId;
      acc[key] ||= { doctor: p.assignedDoctorName || '-', patients: 0, paid: 0, outstanding: 0 };
      acc[key].patients += 1;
      acc[key].paid += p.paidAmount;
      acc[key].outstanding += p.remainingBalance;
      return acc;
    }, {});
    return { patients, appointments, transactions, doctorPerformance: Object.values(doctors) };
  }, [data, from, to]);

  const summaries = useMemo(() => {
    const currencies = ['YER', 'SAR', 'USD'] as const;
    return currencies.map((currency) => {
      const tx = report.transactions.filter((t) => t.currency === currency);
      const income = tx.filter((t) => ['income', 'payment'].includes(t.type)).reduce((sum, t) => sum + t.amount, 0);
      const expenses = tx.filter((t) => ['expense', 'salary', 'advance', 'commission'].includes(t.type)).reduce((sum, t) => sum + t.amount, 0);
      const outstanding = report.patients.filter((p) => p.currency === currency).reduce((sum, p) => sum + p.remainingBalance, 0);
      return { currency, income, expenses, net: income - expenses, outstanding };
    });
  }, [report]);

  function exportReportJson() {
    exportJson(`clinic-report-${from}-${to}.json`, { from, to, summaries, ...report });
  }

  function exportReportExcel() {
    exportExcelHtml(`clinic-report-${from}-${to}.xls`, {
      summaries: summaries as any,
      patients: report.patients as any,
      appointments: report.appointments as any,
      transactions: report.transactions as any,
      doctorPerformance: report.doctorPerformance as any
    });
  }

  function exportPdf() {
    const rows = summaries.map((s) => `<tr><td>${escapeHtml(s.currency)}</td><td>${escapeHtml(s.income)}</td><td>${escapeHtml(s.expenses)}</td><td>${escapeHtml(s.net)}</td><td>${escapeHtml(s.outstanding)}</td></tr>`).join('');
    printHtmlReport('تقرير العيادة', `<p class="muted">من ${escapeHtml(from)} إلى ${escapeHtml(to)}</p><table><thead><tr><th>العملة</th><th>الدخل</th><th>المصروفات</th><th>الصافي</th><th>المتبقي</th></tr></thead><tbody>${rows}</tbody></table>`);
  }

  return (
    <div>
      <PageHeader title="التقارير والتحليلات" description="تقارير يومية/أسبوعية/شهرية/سنوية أو نطاق مخصص مع تصدير PDF وExcel." action={<div className="flex flex-wrap gap-2"><Button variant="secondary" onClick={exportReportJson}>JSON</Button><Button variant="secondary" onClick={exportReportExcel}>Excel</Button><Button onClick={exportPdf}>PDF</Button></div>} />
      <Card className="mb-5">
        <div className="grid gap-3 md:grid-cols-4">
          <Field label="من"><Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></Field>
          <Field label="إلى"><Input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></Field>
          <Button variant="secondary" onClick={() => { const d = todayInputValue(); setFrom(d); setTo(d); }}>تقرير يومي</Button>
          <Button variant="secondary" onClick={() => { const d = new Date(); d.setDate(d.getDate() - 7); setFrom(d.toISOString().slice(0, 10)); setTo(todayInputValue()); }}>آخر أسبوع</Button>
        </div>
      </Card>
      <div className="mb-5 grid gap-4 md:grid-cols-3">
        {summaries.map((s) => <StatCard key={s.currency} title={`ملخص ${s.currency}`} value={formatMoney(s.net, s.currency)} hint={`دخل ${formatMoney(s.income, s.currency)} · مصروف ${formatMoney(s.expenses, s.currency)} · متبقي ${formatMoney(s.outstanding, s.currency)}`} />)}
      </div>
      <div className="grid gap-5 xl:grid-cols-2">
        <TableWrap><thead><tr><Th>المؤشر</Th><Th>القيمة</Th></tr></thead><tbody className="divide-y divide-slate-100"><tr><Td>عدد المرضى</Td><Td>{report.patients.length}</Td></tr><tr><Td>عدد المواعيد</Td><Td>{report.appointments.length}</Td></tr><tr><Td>مواعيد مكتملة</Td><Td>{report.appointments.filter((a) => a.status === 'completed').length}</Td></tr><tr><Td>مواعيد ملغاة</Td><Td>{report.appointments.filter((a) => a.status === 'cancelled').length}</Td></tr></tbody></TableWrap>
        <TableWrap><thead><tr><Th>الطبيب</Th><Th>المرضى</Th><Th>مدفوع</Th><Th>متبقي</Th></tr></thead><tbody className="divide-y divide-slate-100">{report.doctorPerformance.map((d) => <tr key={d.doctor}><Td>{d.doctor}</Td><Td>{d.patients}</Td><Td>{d.paid}</Td><Td>{d.outstanding}</Td></tr>)}</tbody></TableWrap>
      </div>
    </div>
  );
}
