import { useState } from 'react';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Field, Input, Select } from '../components/ui/Form';
import { PageHeader } from '../components/ui/Page';
import { TableWrap, Td, Th } from '../components/ui/Table';
import { managedModules, moduleLabels, permissionLabels, makeDefaultPermissions } from '../config/permissions';
import { useAuth } from '../hooks/useAuth';
import { useAsyncData } from '../hooks/useAsyncData';
import { createOrUpdateUser, listActiveUsers, listEmployees, saveEmployee } from '../services/repositories';
import type { Currency, PermissionLevel, PermissionMap, UserRole } from '../types';
import { formatMoney, toNumber } from '../lib/utils';

const roles: Record<UserRole, string> = {
  admin: 'مدير',
  doctor: 'طبيب',
  receptionist: 'استقبال',
  accountant: 'محاسب'
};

export function EmployeesPage() {
  const { user } = useAuth();
  const [userForm, setUserForm] = useState({ fullName: '', username: '', password: '', role: 'receptionist' as UserRole, phone: '', permissions: makeDefaultPermissions('receptionist') });
  const [employeeForm, setEmployeeForm] = useState({ fullName: '', jobTitle: '', role: 'other', phone: '', monthlySalary: 0, currency: 'YER' as Currency, active: true });
  const { data, reload } = useAsyncData(async () => ({ users: await listActiveUsers(), employees: await listEmployees() }), []);

  function changeRole(role: UserRole) {
    setUserForm({ ...userForm, role, permissions: makeDefaultPermissions(role) });
  }

  function changePermission(module: keyof PermissionMap, level: PermissionLevel) {
    setUserForm({ ...userForm, permissions: { ...userForm.permissions, [module]: level } });
  }

  async function submitUser(event: React.FormEvent) {
    event.preventDefault();
    await createOrUpdateUser(userForm, user);
    setUserForm({ fullName: '', username: '', password: '', role: 'receptionist', phone: '', permissions: makeDefaultPermissions('receptionist') });
    await reload();
  }

  async function submitEmployee(event: React.FormEvent) {
    event.preventDefault();
    await saveEmployee(employeeForm as any, user);
    setEmployeeForm({ fullName: '', jobTitle: '', role: 'other', phone: '', monthlySalary: 0, currency: 'YER', active: true });
    await reload();
  }

  return (
    <div>
      <PageHeader title="الموظفون والصلاحيات" description="إنشاء المستخدمين وتخصيص Full / Partial / View / No لكل وحدة." />
      <div className="mb-5 grid gap-5 xl:grid-cols-2">
        <Card>
          <h2 className="mb-3 font-extrabold text-slate-900">إنشاء مستخدم للنظام</h2>
          <form onSubmit={submitUser} className="grid gap-3 md:grid-cols-2">
            <Field label="الاسم"><Input required value={userForm.fullName} onChange={(e) => setUserForm({ ...userForm, fullName: e.target.value })} /></Field>
            <Field label="اسم المستخدم"><Input required value={userForm.username} onChange={(e) => setUserForm({ ...userForm, username: e.target.value.trim().toLowerCase() })} /></Field>
            <Field label="كلمة المرور"><Input required type="password" value={userForm.password} onChange={(e) => setUserForm({ ...userForm, password: e.target.value })} /></Field>
            <Field label="الدور"><Select value={userForm.role} onChange={(e) => changeRole(e.target.value as UserRole)}>{Object.entries(roles).map(([key, label]) => <option key={key} value={key}>{label}</option>)}</Select></Field>
            <div className="md:col-span-2 rounded-2xl border border-slate-200 p-3">
              <p className="mb-3 text-xs font-extrabold text-slate-500">صلاحيات مخصصة</p>
              <div className="grid gap-2 sm:grid-cols-2">
                {managedModules.map((module) => (
                  <Field key={module} label={moduleLabels[module]}>
                    <Select value={userForm.permissions[module as keyof PermissionMap]} onChange={(e) => changePermission(module as keyof PermissionMap, e.target.value as PermissionLevel)}>
                      {Object.entries(permissionLabels).map(([key, label]) => <option key={key} value={key}>{label}</option>)}
                    </Select>
                  </Field>
                ))}
              </div>
            </div>
            <Button className="md:col-span-2" type="submit">حفظ المستخدم</Button>
          </form>
        </Card>
        <Card>
          <h2 className="mb-3 font-extrabold text-slate-900">ملف موظف / راتب</h2>
          <form onSubmit={submitEmployee} className="grid gap-3 md:grid-cols-2">
            <Field label="الاسم"><Input required value={employeeForm.fullName} onChange={(e) => setEmployeeForm({ ...employeeForm, fullName: e.target.value })} /></Field>
            <Field label="المسمى"><Input required value={employeeForm.jobTitle} onChange={(e) => setEmployeeForm({ ...employeeForm, jobTitle: e.target.value })} /></Field>
            <Field label="الهاتف"><Input value={employeeForm.phone} onChange={(e) => setEmployeeForm({ ...employeeForm, phone: e.target.value })} /></Field>
            <Field label="الراتب الشهري"><Input type="number" value={employeeForm.monthlySalary} onChange={(e) => setEmployeeForm({ ...employeeForm, monthlySalary: toNumber(e.target.value) })} /></Field>
            <Field label="العملة"><Select value={employeeForm.currency} onChange={(e) => setEmployeeForm({ ...employeeForm, currency: e.target.value as Currency })}><option value="YER">YER</option><option value="SAR">SAR</option><option value="USD">USD</option></Select></Field>
            <Button className="md:col-span-2" type="submit">حفظ الموظف</Button>
          </form>
        </Card>
      </div>

      <div className="grid gap-5 xl:grid-cols-2">
        <TableWrap>
          <thead><tr><Th>المستخدم</Th><Th>الدور</Th><Th>الحالة</Th></tr></thead>
          <tbody className="divide-y divide-slate-100">{data?.users.map((u) => <tr key={u.id}><Td><strong>{u.fullName}</strong><div className="text-xs text-slate-500">{u.username}</div></Td><Td>{roles[u.role]}</Td><Td><Badge tone={u.active ? 'green' : 'red'}>{u.active ? 'مفعل' : 'معطل'}</Badge></Td></tr>)}</tbody>
        </TableWrap>
        <TableWrap>
          <thead><tr><Th>الموظف</Th><Th>المسمى</Th><Th>الراتب</Th><Th>الحالة</Th></tr></thead>
          <tbody className="divide-y divide-slate-100">{data?.employees.map((e) => <tr key={e.id}><Td><strong>{e.fullName}</strong><div className="text-xs text-slate-500">{e.phone || '-'}</div></Td><Td>{e.jobTitle}</Td><Td>{formatMoney(e.monthlySalary, e.currency)}</Td><Td><Badge tone={e.active ? 'green' : 'red'}>{e.active ? 'نشط' : 'موقوف'}</Badge></Td></tr>)}</tbody>
        </TableWrap>
      </div>
    </div>
  );
}
