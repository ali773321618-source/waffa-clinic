import { useMemo, useState } from 'react';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Field, Input, Select, Textarea } from '../components/ui/Form';
import { EmptyState, PageHeader } from '../components/ui/Page';
import { TableWrap, Td, Th } from '../components/ui/Table';
import { canWrite } from '../config/permissions';
import { useAuth } from '../hooks/useAuth';
import { useAsyncData } from '../hooks/useAsyncData';
import { dateTimeInputValue, formatDateTime, todayInputValue } from '../lib/utils';
import { deleteAppointment, listAppointmentsForUser, listDoctors, listPatientsForUser, saveAppointment, updateAppointmentStatus } from '../services/repositories';
import type { AppointmentStatus } from '../types';

const statusLabels: Record<AppointmentStatus, string> = {
  scheduled: 'مجدول',
  completed: 'مكتمل',
  cancelled: 'ملغي',
  rescheduled: 'معاد جدولته'
};

export function AppointmentsPage() {
  const { user } = useAuth();
  const writable = canWrite(user, 'appointments');
  const [dateFilter, setDateFilter] = useState(todayInputValue());
  const [form, setForm] = useState({ patientId: '', doctorId: '', appointmentAt: dateTimeInputValue(), status: 'scheduled' as AppointmentStatus, notes: '' });

  const { data, reload } = useAsyncData(async () => {
    if (!user) return { appointments: [], patients: [], doctors: [] };
    const [appointments, patients, doctors] = await Promise.all([listAppointmentsForUser(user), listPatientsForUser(user), listDoctors()]);
    return { appointments, patients, doctors };
  }, [user?.id]);

  const visibleAppointments = useMemo(() => (data?.appointments || [])
    .filter((a) => !dateFilter || a.appointmentAt.slice(0, 10) === dateFilter)
    .sort((a, b) => a.appointmentAt.localeCompare(b.appointmentAt)), [data?.appointments, dateFilter]);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (!user) return;
    const doctorId = user.role === 'doctor' ? user.doctorId || user.id : form.doctorId;
    await saveAppointment({ ...form, doctorId: doctorId || form.doctorId }, user);
    setForm({ patientId: '', doctorId: '', appointmentAt: dateTimeInputValue(), status: 'scheduled', notes: '' });
    await reload();
  }

  return (
    <div>
      <PageHeader title="المواعيد" description="جدولة المواعيد اليومية، إعادة الجدولة، الإكمال، الإلغاء، وتحديثات Realtime عند تفعيل Supabase." />
      <div className="mb-5 grid gap-4 lg:grid-cols-[1fr_280px]">
        {writable ? (
          <Card>
            <form onSubmit={submit} className="grid gap-3 md:grid-cols-2 xl:grid-cols-5">
              <Field label="المريض"><Select required value={form.patientId} onChange={(e) => setForm({ ...form, patientId: e.target.value })}><option value="">اختر المريض</option>{data?.patients.map((p) => <option key={p.id} value={p.id}>{p.fullName}</option>)}</Select></Field>
              <Field label="الطبيب"><Select required value={user?.role === 'doctor' ? user.doctorId || user.id : form.doctorId} disabled={user?.role === 'doctor'} onChange={(e) => setForm({ ...form, doctorId: e.target.value })}><option value="">اختر الطبيب</option>{data?.doctors.map((d) => <option key={d.id} value={d.doctorId || d.id}>{d.fullName}</option>)}</Select></Field>
              <Field label="وقت الموعد"><Input required type="datetime-local" value={form.appointmentAt} onChange={(e) => setForm({ ...form, appointmentAt: e.target.value })} /></Field>
              <Field label="الحالة"><Select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as AppointmentStatus })}>{Object.entries(statusLabels).map(([key, label]) => <option key={key} value={key}>{label}</option>)}</Select></Field>
              <Field label="ملاحظات"><Textarea rows={1} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Field>
              <Button className="md:col-span-2 xl:col-span-5" type="submit">حفظ الموعد</Button>
            </form>
          </Card>
        ) : <div />}
        <Card>
          <Field label="عرض مواعيد يوم"><Input type="date" value={dateFilter} onChange={(e) => setDateFilter(e.target.value)} /></Field>
          <Button className="mt-3 w-full" variant="secondary" onClick={() => setDateFilter('')}>عرض الكل</Button>
        </Card>
      </div>

      {visibleAppointments.length === 0 ? <EmptyState title="لا توجد مواعيد" /> : (
        <TableWrap>
          <thead><tr><Th>المريض</Th><Th>الطبيب</Th><Th>الوقت</Th><Th>الحالة</Th><Th>ملاحظات</Th><Th>إجراءات</Th></tr></thead>
          <tbody className="divide-y divide-slate-100">
            {visibleAppointments.map((appointment) => (
              <tr key={appointment.id}>
                <Td><strong>{appointment.patientName}</strong></Td>
                <Td>{appointment.doctorName}</Td>
                <Td>{formatDateTime(appointment.appointmentAt)}</Td>
                <Td><Badge tone={appointment.status === 'completed' ? 'green' : appointment.status === 'cancelled' ? 'red' : appointment.status === 'rescheduled' ? 'yellow' : 'blue'}>{statusLabels[appointment.status]}</Badge></Td>
                <Td>{appointment.notes || '-'}</Td>
                <Td>
                  {writable ? <div className="flex flex-wrap gap-2">
                    <Button variant="secondary" onClick={() => updateAppointmentStatus(appointment, 'completed', user)}>مكتمل</Button>
                    <Button variant="secondary" onClick={() => updateAppointmentStatus(appointment, 'rescheduled', user)}>إعادة جدولة</Button>
                    <Button variant="danger" onClick={() => updateAppointmentStatus(appointment, 'cancelled', user)}>إلغاء</Button>
                    <Button variant="ghost" onClick={() => deleteAppointment(appointment, user)}>أرشفة</Button>
                  </div> : '-' }
                </Td>
              </tr>
            ))}
          </tbody>
        </TableWrap>
      )}
    </div>
  );
}
