import { useRef, useState } from 'react';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { PageHeader } from '../components/ui/Page';
import { db } from '../lib/db';
import { exportExcelHtml, exportJson } from '../lib/exporters';
import { notifyDataChanged } from '../lib/events';
import { logActivity } from '../services/repositories';
import { useAuth } from '../hooks/useAuth';

async function collectBackup() {
  return {
    exportedAt: new Date().toISOString(),
    version: 1,
    tables: {
      users: await db.users.toArray(),
      patients: await db.patients.toArray(),
      appointments: await db.appointments.toArray(),
      transactions: await db.transactions.toArray(),
      employees: await db.employees.toArray(),
      inventory: await db.inventory.toArray(),
      activityLogs: await db.activityLogs.toArray(),
      settings: await db.settings.toArray()
    }
  };
}

export function BackupPage() {
  const { user } = useAuth();
  const inputRef = useRef<HTMLInputElement>(null);
  const [message, setMessage] = useState('');

  async function exportBackupJson() {
    const backup = await collectBackup();
    exportJson(`clinic-backup-${new Date().toISOString().slice(0, 10)}.json`, backup);
    await logActivity(user, 'backup', 'تصدير نسخة JSON');
  }

  async function exportBackupExcel() {
    const backup = await collectBackup();
    exportExcelHtml(`clinic-backup-${new Date().toISOString().slice(0, 10)}.xls`, backup.tables as any);
    await logActivity(user, 'backup', 'تصدير نسخة Excel');
  }

  async function restore(file: File) {
    const text = await file.text();
    const parsed = JSON.parse(text);
    if (!parsed?.tables) throw new Error('ملف النسخة غير صالح.');
    await db.transaction('rw', [db.users, db.patients, db.appointments, db.transactions, db.employees, db.inventory, db.activityLogs, db.settings], async () => {
      for (const row of parsed.tables.users || []) await db.users.put(row);
      for (const row of parsed.tables.patients || []) await db.patients.put(row);
      for (const row of parsed.tables.appointments || []) await db.appointments.put(row);
      for (const row of parsed.tables.transactions || []) await db.transactions.put(row);
      for (const row of parsed.tables.employees || []) await db.employees.put(row);
      for (const row of parsed.tables.inventory || []) await db.inventory.put(row);
      for (const row of parsed.tables.activityLogs || []) await db.activityLogs.put(row);
      for (const row of parsed.tables.settings || []) await db.settings.put(row);
    });
    notifyDataChanged();
    await logActivity(user, 'backup', 'استعادة نسخة احتياطية', file.name);
    setMessage('تمت الاستعادة محلياً. عند توفر الإنترنت ستستمر المزامنة حسب قائمة الانتظار.');
  }

  return (
    <div>
      <PageHeader title="النسخ الاحتياطي والاستعادة" description="تصدير بيانات العيادة JSON أو Excel، واستعادة نسخة سابقة بشكل آمن." />
      <div className="grid gap-4 md:grid-cols-3">
        <Card><h2 className="font-extrabold">نسخة JSON</h2><p className="my-2 text-sm text-slate-500">أفضل صيغة للاستعادة الكاملة.</p><Button onClick={exportBackupJson}>تصدير JSON</Button></Card>
        <Card><h2 className="font-extrabold">نسخة Excel</h2><p className="my-2 text-sm text-slate-500">مناسبة للمراجعة الإدارية والمالية.</p><Button variant="secondary" onClick={exportBackupExcel}>تصدير Excel</Button></Card>
        <Card><h2 className="font-extrabold">استعادة</h2><p className="my-2 text-sm text-slate-500">اختر ملف JSON صادر من النظام.</p><input ref={inputRef} type="file" accept="application/json,.json" className="hidden" onChange={(e) => e.target.files?.[0] && restore(e.target.files[0]).catch((err) => setMessage(err.message))} /><Button variant="secondary" onClick={() => inputRef.current?.click()}>اختيار ملف</Button></Card>
      </div>
      {message ? <Card className="mt-5 text-sm font-bold text-slate-700">{message}</Card> : null}
    </div>
  );
}
