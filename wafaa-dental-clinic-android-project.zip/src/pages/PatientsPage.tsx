import { useMemo, useState } from 'react';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Field, Input, Select, Textarea } from '../components/ui/Form';
import { EmptyState, PageHeader } from '../components/ui/Page';
import { TableWrap, Td, Th } from '../components/ui/Table';
import { canWrite } from '../config/permissions';
import { useAuth } from '../hooks/useAuth';
import { useAsyncData } from '../hooks/useAsyncData';
import { buildPatientWhatsAppMessage, makeWhatsAppUrl } from '../lib/whatsapp';
import { deletePatient, listDoctors, listPatientsForUser, savePatient, toggleTreatmentCompleted, updatePatientNotes } from '../services/repositories';
import type { Currency, Patient } from '../types';
import { formatMoney, toNumber } from '../lib/utils';

const defaultForm = {
  fullName: '',
  age: 0,
  phone: '',
  assignedDoctorId: '',
  procedureType: '',
  totalCost: 0,
  paidAmount: 0,
  currency: 'YER' as Currency,
  treatmentCompleted: false,
  notes: ''
};

export function PatientsPage() {
  const { user } = useAuth();
  const writable = canWrite(user, 'patients');
  const [form, setForm] = useState(defaultForm);
  const [notesDraft, setNotesDraft] = useState<Record<string, string>>({});
  const { data, loading, reload } = useAsyncData(async () => {
    if (!user) return { patients: [], doctors: [] };
    const [patients, doctors] = await Promise.all([listPatientsForUser(user), listDoctors()]);
    return { patients, doctors };
  }, [user?.id]);

  const remaining = useMemo(() => Math.max(toNumber(form.totalCost) - toNumber(form.paidAmount), 0), [form.totalCost, form.paidAmount]);
  const selectedDoctors = data?.doctors || [];

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (!user) return;
    const doctorId = user.role === 'doctor' ? user.doctorId || user.id : form.assignedDoctorId;
    await savePatient({ ...form, assignedDoctorId: doctorId || form.assignedDoctorId }, user);
    setForm(defaultForm);
    await reload();
  }

  const patients = data?.patients || [];

  return (
    <div>
      <PageHeader title="إدارة المرضى" description="إضافة المرضى، الحسابات، حالة الدفع، رسالة واتساب، وملاحظات العلاج." />
      {writable ? (
        <Card className="mb-5">
          <form onSubmit={submit} className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
            <Field label="اسم المريض الكامل"><Input required value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} /></Field>
            <Field label="العمر"><Input type="number" min={0} value={form.age} onChange={(e) => setForm({ ...form, age: toNumber(e.target.value) })} /></Field>
            <Field label="رقم الهاتف"><Input required dir="ltr" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field>
            <Field label="الطبيب المسؤول">
              <Select required value={user?.role === 'doctor' ? user.doctorId || user.id : form.assignedDoctorId} disabled={user?.role === 'doctor'} onChange={(e) => setForm({ ...form, assignedDoctorId: e.target.value })}>
                <option value="">اختر الطبيب</option>
                {selectedDoctors.map((doctor) => <option key={doctor.id} value={doctor.doctorId || doctor.id}>{doctor.fullName}</option>)}
              </Select>
            </Field>
            <Field label="نوع الإجراء / العلاج"><Input required value={form.procedureType} onChange={(e) => setForm({ ...form, procedureType: e.target.value })} /></Field>
            <Field label="العملة">
              <Select value={form.currency} onChange={(e) => setForm({ ...form, currency: e.target.value as Currency })}>
                <option value="YER">YER</option><option value="SAR">SAR</option><option value="USD">USD</option>
              </Select>
            </Field>
            <Field label="إجمالي التكلفة"><Input type="number" min={0} value={form.totalCost} onChange={(e) => setForm({ ...form, totalCost: toNumber(e.target.value) })} /></Field>
            <Field label="المبلغ المدفوع"><Input type="number" min={0} value={form.paidAmount} onChange={(e) => setForm({ ...form, paidAmount: toNumber(e.target.value) })} /></Field>
            <div className="rounded-xl bg-slate-50 p-3 text-sm font-extrabold text-slate-700">المتبقي: {formatMoney(remaining, form.currency)}</div>
            <label className="flex items-center gap-2 rounded-xl bg-slate-50 p-3 text-sm font-bold text-slate-700"><input type="checkbox" checked={form.treatmentCompleted} onChange={(e) => setForm({ ...form, treatmentCompleted: e.target.checked })} /> علاج مكتمل</label>
            <div className="md:col-span-2 xl:col-span-4"><Field label="ملاحظات علاجية"><Textarea rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Field></div>
            <Button type="submit" className="md:col-span-2 xl:col-span-4">حفظ المريض</Button>
          </form>
        </Card>
      ) : null}

      {loading ? <p className="text-sm text-slate-500">جاري التحميل...</p> : patients.length === 0 ? <EmptyState /> : (
        <TableWrap>
          <thead><tr><Th>المريض</Th><Th>الطبيب</Th><Th>العلاج</Th><Th>الحساب</Th><Th>الحالة</Th><Th>واتساب</Th><Th>ملاحظات</Th><Th>إجراءات</Th></tr></thead>
          <tbody className="divide-y divide-slate-100">
            {patients.map((patient: Patient) => {
              const message = buildPatientWhatsAppMessage(patient);
              const url = makeWhatsAppUrl(patient.phone, message);
              return (
                <tr key={patient.id}>
                  <Td><div className="font-extrabold text-slate-900">{patient.fullName}</div><div className="text-xs text-slate-500" dir="ltr">{patient.phone}</div></Td>
                  <Td>{patient.assignedDoctorName || '-'}</Td>
                  <Td>{patient.procedureType}</Td>
                  <Td><div>{formatMoney(patient.totalCost, patient.currency)}</div><div className="text-xs text-slate-500">مدفوع: {formatMoney(patient.paidAmount, patient.currency)} · متبقي: {formatMoney(patient.remainingBalance, patient.currency)}</div></Td>
                  <Td><div className="space-y-1"><Badge tone={patient.paymentStatus === 'paid' ? 'green' : 'red'}>{patient.paymentStatus === 'paid' ? 'مكتمل الدفع' : 'غير مكتمل'}</Badge><br/><Badge tone={patient.treatmentCompleted ? 'green' : 'yellow'}>{patient.treatmentCompleted ? 'علاج مكتمل' : 'قيد العلاج'}</Badge></div></Td>
                  <Td><a className="inline-flex rounded-xl bg-emerald-600 px-3 py-2 text-xs font-extrabold text-white" href={url} target="_blank" rel="noreferrer">إرسال رسالة واتساب</a></Td>
                  <Td>
                    <Textarea className="min-w-64" rows={2} value={notesDraft[patient.id] ?? patient.notes ?? ''} onChange={(e) => setNotesDraft({ ...notesDraft, [patient.id]: e.target.value })} disabled={!writable && user?.role !== 'doctor'} />
                    {(writable || user?.role === 'doctor') ? <Button className="mt-2" variant="secondary" onClick={() => updatePatientNotes(patient, notesDraft[patient.id] ?? patient.notes ?? '', user)}>حفظ</Button> : null}
                  </Td>
                  <Td><div className="flex flex-wrap gap-2">{writable ? <Button variant="secondary" onClick={() => toggleTreatmentCompleted(patient, user)}>تبديل العلاج</Button> : null}{writable ? <Button variant="danger" onClick={() => deletePatient(patient, user)}>أرشفة</Button> : null}</div></Td>
                </tr>
              );
            })}
          </tbody>
        </TableWrap>
      )}
    </div>
  );
}
