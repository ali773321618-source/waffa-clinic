import { useState } from 'react';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Field, Input } from '../components/ui/Form';
import { PageHeader } from '../components/ui/Page';
import { db } from '../lib/db';
import { notifyDataChanged } from '../lib/events';
import { nowIso } from '../lib/utils';
import { useAsyncData } from '../hooks/useAsyncData';

export function SettingsPage() {
  const { data, reload } = useAsyncData(async () => await db.settings.get('clinicName'), []);
  const [clinicName, setClinicName] = useState('');
  const value = clinicName || String(data?.value || 'عيادة د. وفاء عبدالكريم');

  async function save() {
    await db.settings.put({ key: 'clinicName', value, updatedAt: nowIso() });
    notifyDataChanged();
    await reload();
    setClinicName('');
  }

  return (
    <div>
      <PageHeader title="الإعدادات" description="إعدادات أساسية خفيفة ومناسبة للتطبيقات المبنية كـ APK." />
      <Card className="max-w-xl">
        <Field label="اسم العيادة"><Input value={value} onChange={(e) => setClinicName(e.target.value)} /></Field>
        <Button className="mt-4" onClick={save}>حفظ</Button>
      </Card>
    </div>
  );
}
