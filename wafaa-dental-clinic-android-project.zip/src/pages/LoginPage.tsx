import { useState } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Field, Input } from '../components/ui/Form';

export function LoginPage() {
  const { user, login } = useAuth();
  const location = useLocation();
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('admin123');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (user) return <Navigate to={(location.state as any)?.from?.pathname || '/'} replace />;

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError('');
    setLoading(true);
    try {
      await login(username, password);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-clinic-50 via-white to-slate-100 p-4" dir="rtl">
      <Card className="w-full max-w-md p-6">
        <div className="mb-6 text-center">
          <div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-3xl bg-clinic-700 text-2xl font-extrabold text-white">د</div>
          <h1 className="text-2xl font-extrabold text-slate-950">عيادة د. وفاء عبدالكريم</h1>
          <p className="mt-2 text-sm text-slate-500">نظام إدارة العيادة والمحاسبة — يعمل أونلاين وأوفلاين</p>
        </div>
        <form onSubmit={submit} className="space-y-4">
          <Field label="اسم المستخدم">
            <Input value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" />
          </Field>
          <Field label="كلمة المرور">
            <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" />
          </Field>
          {error ? <p className="rounded-xl bg-red-50 p-3 text-sm font-bold text-red-700">{error}</p> : null}
          <Button type="submit" className="w-full" disabled={loading}>{loading ? 'جاري الدخول...' : 'تسجيل الدخول'}</Button>
        </form>
        <div className="mt-5 rounded-xl bg-slate-50 p-3 text-xs leading-6 text-slate-500">
          الحسابات الأولية بعد أول تشغيل: admin/admin123، doctor/doctor123، reception/reception123، accountant/accountant123. غيّرها فوراً من صفحة الموظفين.
        </div>
      </Card>
    </div>
  );
}
