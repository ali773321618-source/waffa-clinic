import { useState } from 'react';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Card, StatCard } from '../components/ui/Card';
import { Field, Input, Select } from '../components/ui/Form';
import { EmptyState, PageHeader } from '../components/ui/Page';
import { TableWrap, Td, Th } from '../components/ui/Table';
import { canWrite } from '../config/permissions';
import { useAuth } from '../hooks/useAuth';
import { useAsyncData } from '../hooks/useAsyncData';
import { deleteTransaction, getCurrencySummaries, listDoctors, listEmployees, listTransactionsForUser, saveTransaction } from '../services/repositories';
import type { Currency, ExpenseCategory, TransactionType } from '../types';
import { formatDate, formatMoney, todayInputValue, toNumber } from '../lib/utils';

const expenseCategories: Record<ExpenseCategory, string> = {
  rent: 'إيجار',
  supplies: 'مستلزمات',
  utilities: 'خدمات',
  equipment: 'معدات',
  maintenance: 'صيانة',
  marketing: 'تسويق',
  miscellaneous: 'متفرقات'
};

const typeLabels: Record<TransactionType, string> = {
  income: 'دخل',
  expense: 'مصروف',
  payment: 'دفعة مريض',
  salary: 'راتب',
  advance: 'سلفة موظف',
  commission: 'عمولة طبيب'
};

export function AccountingPage() {
  const { user } = useAuth();
  const writable = canWrite(user, 'financials') && user?.role !== 'doctor';
  const [form, setForm] = useState({ type: 'expense' as TransactionType, amount: 0, currency: 'YER' as Currency, description: '', category: 'supplies', date: todayInputValue(), doctorId: '', employeeId: '' });

  const { data, reload } = useAsyncData(async () => {
    if (!user) return { summaries: [], transactions: [], doctors: [], employees: [] };
    const [summaries, transactions, doctors, employees] = await Promise.all([getCurrencySummaries(user), listTransactionsForUser(user), listDoctors(), listEmployees()]);
    return { summaries, transactions: transactions.sort((a, b) => b.date.localeCompare(a.date)), doctors, employees };
  }, [user?.id]);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (!user) return;
    await saveTransaction({
      type: form.type,
      amount: toNumber(form.amount),
      currency: form.currency,
      description: form.description || typeLabels[form.type],
      category: form.type === 'expense' ? form.category : undefined,
      doctorId: form.doctorId || undefined,
      employeeId: form.employeeId || undefined,
      date: form.date
    }, user);
    setForm({ type: 'expense', amount: 0, currency: 'YER', description: '', category: 'supplies', date: todayInputValue(), doctorId: '', employeeId: '' });
    await reload();
  }

  return (
    <div>
      <PageHeader title={user?.role === 'doctor' ? 'البيانات المالية لمرضاي' : 'المحاسبة'} description="فصل صارم بين العملات: YER / SAR / USD بدون تحويل أو خلط." />
      <div className="mb-5 grid gap-4 md:grid-cols-3">
        {data?.summaries.map((s) => <StatCard key={s.currency} title={`صافي ${s.currency}`} value={formatMoney(s.netProfit, s.currency)} hint={`دخل ${formatMoney(s.income, s.currency)} · مصروف ${formatMoney(s.expenses, s.currency)} · متبقي ${formatMoney(s.outstanding, s.currency)} · عمولات ${formatMoney(s.doctorCommissions, s.currency)}`} />)}
      </div>

      {writable ? (
        <Card className="mb-5">
          <form onSubmit={submit} className="grid gap-3 md:grid-cols-2 xl:grid-cols-6">
            <Field label="نوع الحركة"><Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as TransactionType })}>{Object.entries(typeLabels).map(([key, label]) => <option key={key} value={key}>{label}</option>)}</Select></Field>
            <Field label="المبلغ"><Input type="number" min={0} value={form.amount} onChange={(e) => setForm({ ...form, amount: toNumber(e.target.value) })} /></Field>
            <Field label="العملة"><Select value={form.currency} onChange={(e) => setForm({ ...form, currency: e.target.value as Currency })}><option value="YER">YER</option><option value="SAR">SAR</option><option value="USD">USD</option></Select></Field>
            <Field label="التاريخ"><Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></Field>
            <Field label="الفئة"><Select disabled={form.type !== 'expense'} value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>{Object.entries(expenseCategories).map(([key, label]) => <option key={key} value={key}>{label}</option>)}</Select></Field>
            <Field label="الوصف"><Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></Field>
            <Field label="الطبيب للعمولة"><Select value={form.doctorId} onChange={(e) => setForm({ ...form, doctorId: e.target.value })}><option value="">بدون</option>{data?.doctors.map((d) => <option key={d.id} value={d.doctorId || d.id}>{d.fullName}</option>)}</Select></Field>
            <Field label="الموظف للراتب/السلفة"><Select value={form.employeeId} onChange={(e) => setForm({ ...form, employeeId: e.target.value })}><option value="">بدون</option>{data?.employees.map((e) => <option key={e.id} value={e.id}>{e.fullName}</option>)}</Select></Field>
            <Button className="md:col-span-2 xl:col-span-6" type="submit">حفظ الحركة المالية</Button>
          </form>
        </Card>
      ) : user?.role === 'doctor' ? <Card className="mb-5 text-sm text-slate-600">تظهر هنا فقط الحركات المرتبطة بمرضاك. لا تظهر المصروفات العامة، الرواتب، أو أرباح العيادة.</Card> : null}

      {(data?.transactions.length || 0) === 0 ? <EmptyState title="لا توجد حركات مالية" /> : (
        <TableWrap>
          <thead><tr><Th>التاريخ</Th><Th>النوع</Th><Th>الوصف</Th><Th>الفئة</Th><Th>المبلغ</Th><Th>إجراءات</Th></tr></thead>
          <tbody className="divide-y divide-slate-100">
            {data?.transactions.map((t) => (
              <tr key={t.id}>
                <Td>{formatDate(t.date)}</Td>
                <Td><Badge tone={['income', 'payment'].includes(t.type) ? 'green' : 'red'}>{typeLabels[t.type]}</Badge></Td>
                <Td>{t.description}</Td>
                <Td>{t.category ? expenseCategories[t.category as ExpenseCategory] || t.category : '-'}</Td>
                <Td><strong>{formatMoney(t.amount, t.currency)}</strong></Td>
                <Td>{writable ? <Button variant="danger" onClick={() => deleteTransaction(t, user)}>أرشفة</Button> : '-'}</Td>
              </tr>
            ))}
          </tbody>
        </TableWrap>
      )}
    </div>
  );
}
