import { useMemo, useState } from 'react';
import { Card } from '../components/ui/Card';
import { Field, Input } from '../components/ui/Form';
import { EmptyState, PageHeader } from '../components/ui/Page';
import { TableWrap, Td, Th } from '../components/ui/Table';
import { useAuth } from '../hooks/useAuth';
import { useAsyncData } from '../hooks/useAsyncData';
import { formatDateTime, formatMoney, matchesArabicSearch } from '../lib/utils';
import { listAppointmentsForUser, listEmployees, listPatientsForUser, listTransactionsForUser } from '../services/repositories';

export function SearchPage() {
  const { user } = useAuth();
  const [term, setTerm] = useState('');
  const { data } = useAsyncData(async () => {
    if (!user) return { patients: [], appointments: [], transactions: [], employees: [] };
    const [patients, appointments, transactions, employees] = await Promise.all([listPatientsForUser(user), listAppointmentsForUser(user), listTransactionsForUser(user), listEmployees()]);
    return { patients, appointments, transactions, employees };
  }, [user?.id]);

  const results = useMemo(() => {
    const q = term.trim();
    if (!q) return [];
    const items: Array<{ type: string; title: string; subtitle: string; meta: string }> = [];
    data?.patients.forEach((p) => {
      if ([p.fullName, p.phone, p.procedureType, p.assignedDoctorName].some((x) => matchesArabicSearch(x, q))) items.push({ type: 'مريض', title: p.fullName, subtitle: p.phone, meta: `${p.procedureType} · ${formatMoney(p.remainingBalance, p.currency)} متبقي` });
    });
    data?.appointments.forEach((a) => {
      if ([a.patientName, a.doctorName, a.notes, a.status].some((x) => matchesArabicSearch(x, q))) items.push({ type: 'موعد', title: a.patientName || '-', subtitle: formatDateTime(a.appointmentAt), meta: a.status });
    });
    data?.transactions.forEach((t) => {
      if ([t.description, t.category, t.type, t.currency].some((x) => matchesArabicSearch(x, q))) items.push({ type: 'حركة مالية', title: t.description, subtitle: t.date, meta: formatMoney(t.amount, t.currency) });
    });
    data?.employees.forEach((e) => {
      if ([e.fullName, e.phone, e.jobTitle].some((x) => matchesArabicSearch(x, q))) items.push({ type: 'موظف', title: e.fullName, subtitle: e.jobTitle, meta: e.phone || '-' });
    });
    return items.slice(0, 80);
  }, [data, term]);

  return (
    <div>
      <PageHeader title="البحث العام" description="بحث سريع يدعم العربية عبر المرضى، الأرقام، المواعيد، الموظفين، والحركات المالية." />
      <Card className="mb-5"><Field label="اكتب كلمة البحث"><Input autoFocus value={term} onChange={(e) => setTerm(e.target.value)} placeholder="اسم، رقم، إجراء، موعد، موظف..." /></Field></Card>
      {!term ? <EmptyState title="ابدأ بالبحث" description="النتائج تظهر فوراً أثناء الكتابة." /> : results.length === 0 ? <EmptyState title="لا توجد نتائج" /> : (
        <TableWrap><thead><tr><Th>النوع</Th><Th>العنوان</Th><Th>التفاصيل</Th><Th>معلومة</Th></tr></thead><tbody className="divide-y divide-slate-100">{results.map((r, i) => <tr key={`${r.type}-${i}`}><Td>{r.type}</Td><Td><strong>{r.title}</strong></Td><Td>{r.subtitle}</Td><Td>{r.meta}</Td></tr>)}</tbody></TableWrap>
      )}
    </div>
  );
}
