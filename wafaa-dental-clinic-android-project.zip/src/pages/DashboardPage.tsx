import { StatCard } from '../components/ui/Card';
import { PageHeader } from '../components/ui/Page';
import { useAuth } from '../hooks/useAuth';
import { useAsyncData } from '../hooks/useAsyncData';
import { db } from '../lib/db';
import { formatMoney, todayInputValue } from '../lib/utils';
import { getCurrencySummaries, listAppointmentsForUser, listPatientsForUser } from '../services/repositories';

export function DashboardPage() {
  const { user } = useAuth();
  const { data } = useAsyncData(async () => {
    if (!user) return null;
    const [patients, appointments, summaries, pendingSync] = await Promise.all([
      listPatientsForUser(user),
      listAppointmentsForUser(user),
      getCurrencySummaries(user),
      db.syncQueue.where('status').equals('pending').count()
    ]);
    const today = todayInputValue();
    return {
      patients,
      appointments,
      summaries,
      pendingSync,
      todayAppointments: appointments.filter((a) => a.appointmentAt.slice(0, 10) === today),
      unpaidPatients: patients.filter((p) => p.paymentStatus === 'unpaid')
    };
  }, [user?.id]);

  return (
    <div>
      <PageHeader title="لوحة التحكم" description="نظرة سريعة على المرضى، المواعيد، المبالغ المتبقية، وحالة المزامنة." />
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <StatCard title="إجمالي المرضى" value={data?.patients.length ?? 0} />
        <StatCard title="مواعيد اليوم" value={data?.todayAppointments.length ?? 0} />
        <StatCard title="مرضى غير مكتمل الدفع" value={data?.unpaidPatients.length ?? 0} />
        <StatCard title="عمليات تنتظر المزامنة" value={data?.pendingSync ?? 0} hint="تُرفع تلقائياً عند عودة الإنترنت" />
      </div>
      <div className="mt-5 grid gap-4 lg:grid-cols-3">
        {data?.summaries.map((summary) => (
          <StatCard
            key={summary.currency}
            title={`صافي الربح - ${summary.currency}`}
            value={formatMoney(summary.netProfit, summary.currency)}
            hint={`دخل: ${formatMoney(summary.income, summary.currency)} · مصروف: ${formatMoney(summary.expenses, summary.currency)} · متبقي: ${formatMoney(summary.outstanding, summary.currency)}`}
          />
        ))}
      </div>
    </div>
  );
}
