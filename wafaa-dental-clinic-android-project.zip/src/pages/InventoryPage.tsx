import { useState } from 'react';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Field, Input, Textarea } from '../components/ui/Form';
import { EmptyState, PageHeader } from '../components/ui/Page';
import { TableWrap, Td, Th } from '../components/ui/Table';
import { canWrite } from '../config/permissions';
import { useAuth } from '../hooks/useAuth';
import { useAsyncData } from '../hooks/useAsyncData';
import { listInventory, saveInventoryItem } from '../services/repositories';
import { toNumber } from '../lib/utils';

export function InventoryPage() {
  const { user } = useAuth();
  const writable = canWrite(user, 'inventory');
  const [form, setForm] = useState({ name: '', category: '', quantity: 0, minThreshold: 1, unit: 'قطعة', notes: '' });
  const { data, reload } = useAsyncData(async () => listInventory(), []);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    await saveInventoryItem(form, user);
    setForm({ name: '', category: '', quantity: 0, minThreshold: 1, unit: 'قطعة', notes: '' });
    await reload();
  }

  return (
    <div>
      <PageHeader title="المخزون" description="إدارة المواد والتنبيه عند انخفاض الكمية عن الحد الأدنى." />
      {writable ? (
        <Card className="mb-5">
          <form onSubmit={submit} className="grid gap-3 md:grid-cols-2 xl:grid-cols-6">
            <Field label="اسم الصنف"><Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
            <Field label="الفئة"><Input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} /></Field>
            <Field label="الكمية"><Input type="number" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: toNumber(e.target.value) })} /></Field>
            <Field label="الحد الأدنى"><Input type="number" value={form.minThreshold} onChange={(e) => setForm({ ...form, minThreshold: toNumber(e.target.value) })} /></Field>
            <Field label="الوحدة"><Input value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} /></Field>
            <Field label="ملاحظات"><Textarea rows={1} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Field>
            <Button className="md:col-span-2 xl:col-span-6" type="submit">حفظ الصنف</Button>
          </form>
        </Card>
      ) : null}
      {(data?.length || 0) === 0 ? <EmptyState title="لا توجد أصناف" /> : (
        <TableWrap>
          <thead><tr><Th>الصنف</Th><Th>الفئة</Th><Th>الكمية</Th><Th>الحد الأدنى</Th><Th>الحالة</Th><Th>ملاحظات</Th></tr></thead>
          <tbody className="divide-y divide-slate-100">
            {data?.map((item) => (
              <tr key={item.id}>
                <Td><strong>{item.name}</strong></Td>
                <Td>{item.category || '-'}</Td>
                <Td>{item.quantity} {item.unit}</Td>
                <Td>{item.minThreshold}</Td>
                <Td><Badge tone={item.quantity <= item.minThreshold ? 'red' : 'green'}>{item.quantity <= item.minThreshold ? 'مخزون منخفض' : 'جيد'}</Badge></Td>
                <Td>{item.notes || '-'}</Td>
              </tr>
            ))}
          </tbody>
        </TableWrap>
      )}
    </div>
  );
}
