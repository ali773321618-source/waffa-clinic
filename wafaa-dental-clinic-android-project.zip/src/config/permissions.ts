import type { AppModule, ClinicUser, PermissionLevel, PermissionMap, UserRole } from '../types';

const rank: Record<PermissionLevel, number> = {
  none: 0,
  view: 1,
  partial: 2,
  full: 3
};

export const permissionLabels: Record<PermissionLevel, string> = {
  full: 'وصول كامل',
  partial: 'وصول جزئي',
  view: 'عرض فقط',
  none: 'بدون وصول'
};

export const moduleLabels: Record<AppModule, string> = {
  dashboard: 'لوحة التحكم',
  patients: 'المرضى',
  financials: 'المحاسبة',
  appointments: 'المواعيد',
  employees: 'الموظفون',
  inventory: 'المخزون',
  reports: 'التقارير',
  activityLogs: 'سجل النشاط',
  backup: 'النسخ الاحتياطي',
  settings: 'الإعدادات',
  search: 'البحث'
};

export const managedModules: AppModule[] = [
  'patients',
  'financials',
  'appointments',
  'employees',
  'inventory',
  'reports',
  'activityLogs',
  'backup',
  'settings',
  'search'
];

export const rolePermissions: Record<UserRole, PermissionMap> = {
  admin: {
    patients: 'full',
    financials: 'full',
    appointments: 'full',
    employees: 'full',
    inventory: 'full',
    reports: 'full',
    activityLogs: 'full',
    backup: 'full',
    settings: 'full',
    search: 'full'
  },
  doctor: {
    patients: 'partial',
    financials: 'partial',
    appointments: 'partial',
    employees: 'none',
    inventory: 'view',
    reports: 'none',
    activityLogs: 'none',
    backup: 'none',
    settings: 'none',
    search: 'partial'
  },
  receptionist: {
    patients: 'partial',
    financials: 'none',
    appointments: 'partial',
    employees: 'none',
    inventory: 'view',
    reports: 'none',
    activityLogs: 'none',
    backup: 'none',
    settings: 'none',
    search: 'partial'
  },
  accountant: {
    patients: 'view',
    financials: 'full',
    appointments: 'view',
    employees: 'view',
    inventory: 'view',
    reports: 'full',
    activityLogs: 'view',
    backup: 'full',
    settings: 'none',
    search: 'partial'
  }
};

export function getPermission(user: ClinicUser | null | undefined, module: AppModule): PermissionLevel {
  if (!user || !user.active) return 'none';
  if (module === 'dashboard') return 'view';
  return user.permissions?.[module as keyof PermissionMap] ?? rolePermissions[user.role]?.[module as keyof PermissionMap] ?? 'none';
}

export function hasAccess(user: ClinicUser | null | undefined, module: AppModule, minimum: PermissionLevel = 'view') {
  return rank[getPermission(user, module)] >= rank[minimum];
}

export function canWrite(user: ClinicUser | null | undefined, module: AppModule) {
  return hasAccess(user, module, 'partial');
}

export function makeDefaultPermissions(role: UserRole): PermissionMap {
  return { ...rolePermissions[role] };
}
