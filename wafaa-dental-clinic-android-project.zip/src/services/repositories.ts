import { makeDefaultPermissions } from '../config/permissions';
import type {
  ActivityLog,
  AppModule,
  Appointment,
  ClinicUser,
  Currency,
  CurrencySummary,
  Employee,
  InventoryItem,
  Patient,
  Transaction,
  UserRole
} from '../types';
import { hashPassword } from '../lib/crypto';
import { db } from '../lib/db';
import { softDeleteLocalFirst, upsertLocalFirst } from '../lib/sync';
import { nowIso, uid } from '../lib/utils';

export async function logActivity(actor: ClinicUser | null, module: AppModule, action: string, details?: string) {
  const now = nowIso();
  const log: ActivityLog = {
    id: uid('log'),
    actorId: actor?.id,
    actorName: actor?.fullName,
    module,
    action,
    details,
    createdAt: now,
    updatedAt: now,
    deletedAt: null
  };
  await upsertLocalFirst('activityLogs', log);
}

export async function listActiveUsers() {
  return (await db.users.toArray()).filter((u) => u.active && !u.deletedAt);
}

export async function listDoctors() {
  return (await db.users.where('role').equals('doctor').toArray()).filter((u) => u.active && !u.deletedAt);
}

export async function createOrUpdateUser(input: Partial<ClinicUser> & { fullName: string; username: string; role: UserRole; password?: string }, actor: ClinicUser | null) {
  const now = nowIso();
  const existing = input.id ? await db.users.get(input.id) : undefined;
  const role = input.role;
  const generatedDoctorId = input.doctorId || input.id || uid('doctor');
  const doctorId = role === 'doctor' ? generatedDoctorId : input.doctorId || null;
  const record: ClinicUser = {
    id: input.id || (role === 'doctor' ? generatedDoctorId : uid('user')),
    fullName: input.fullName,
    username: input.username,
    passwordHash: input.password ? await hashPassword(input.password) : existing?.passwordHash || await hashPassword('123456'),
    role,
    doctorId,
    permissions: input.permissions || existing?.permissions || makeDefaultPermissions(role),
    active: input.active ?? existing?.active ?? true,
    phone: input.phone || existing?.phone,
    createdAt: existing?.createdAt || now,
    updatedAt: now,
    deletedAt: input.deletedAt ?? existing?.deletedAt ?? null
  };
  await upsertLocalFirst('users', record);
  await logActivity(actor, 'employees', existing ? 'تعديل مستخدم' : 'إنشاء مستخدم', record.fullName);
  return record;
}

export async function listPatientsForUser(user: ClinicUser) {
  const patients = (await db.patients.toArray()).filter((p) => !p.deletedAt);
  if (user.role === 'doctor') {
    return patients.filter((p) => p.assignedDoctorId === user.doctorId || p.assignedDoctorId === user.id);
  }
  return patients;
}

export async function savePatient(input: Omit<Patient, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt' | 'remainingBalance' | 'paymentStatus'> & Partial<Pick<Patient, 'id' | 'createdAt'>>, actor: ClinicUser | null) {
  const now = nowIso();
  const totalCost = Number(input.totalCost) || 0;
  const paidAmount = Number(input.paidAmount) || 0;
  const remainingBalance = Math.max(totalCost - paidAmount, 0);
  const doctor = await db.users.get(input.assignedDoctorId);
  const record: Patient = {
    ...input,
    id: input.id || uid('patient'),
    assignedDoctorName: doctor?.fullName || input.assignedDoctorName,
    totalCost,
    paidAmount,
    remainingBalance,
    paymentStatus: remainingBalance <= 0 ? 'paid' : 'unpaid',
    treatmentCompleted: Boolean(input.treatmentCompleted),
    createdAt: input.createdAt || now,
    updatedAt: now,
    deletedAt: null
  };
  await upsertLocalFirst('patients', record);

  if (paidAmount > 0) {
    await saveTransaction({
      type: 'payment',
      amount: paidAmount,
      currency: record.currency,
      description: `دفعة من المريض: ${record.fullName}`,
      patientId: record.id,
      doctorId: record.assignedDoctorId,
      date: now.slice(0, 10)
    }, actor, false);
  }

  await logActivity(actor, 'patients', input.id ? 'تعديل مريض' : 'إضافة مريض', record.fullName);
  return record;
}

export async function updatePatientNotes(patient: Patient, notes: string, actor: ClinicUser | null) {
  const record = { ...patient, notes, updatedAt: nowIso() };
  await upsertLocalFirst('patients', record);
  await logActivity(actor, 'patients', 'تحديث ملاحظات علاجية', patient.fullName);
}

export async function toggleTreatmentCompleted(patient: Patient, actor: ClinicUser | null) {
  const record = { ...patient, treatmentCompleted: !patient.treatmentCompleted, updatedAt: nowIso() };
  await upsertLocalFirst('patients', record);
  await logActivity(actor, 'patients', 'تغيير حالة العلاج', patient.fullName);
}

export async function deletePatient(patient: Patient, actor: ClinicUser | null) {
  await softDeleteLocalFirst('patients', patient);
  await logActivity(actor, 'patients', 'أرشفة مريض', patient.fullName);
}

export async function listAppointmentsForUser(user: ClinicUser) {
  const appointments = (await db.appointments.toArray()).filter((a) => !a.deletedAt);
  if (user.role === 'doctor') {
    return appointments.filter((a) => a.doctorId === user.doctorId || a.doctorId === user.id);
  }
  return appointments;
}

export async function saveAppointment(input: Omit<Appointment, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'> & Partial<Pick<Appointment, 'id' | 'createdAt'>>, actor: ClinicUser | null) {
  const now = nowIso();
  const patient = await db.patients.get(input.patientId);
  const doctor = await db.users.get(input.doctorId);
  const record: Appointment = {
    ...input,
    id: input.id || uid('appointment'),
    patientName: patient?.fullName || input.patientName,
    doctorName: doctor?.fullName || input.doctorName,
    createdAt: input.createdAt || now,
    updatedAt: now,
    deletedAt: null
  };
  await upsertLocalFirst('appointments', record);
  await logActivity(actor, 'appointments', input.id ? 'تعديل موعد' : 'إضافة موعد', `${record.patientName || ''} - ${record.status}`);
  return record;
}

export async function updateAppointmentStatus(appointment: Appointment, status: Appointment['status'], actor: ClinicUser | null) {
  const record = { ...appointment, status, updatedAt: nowIso() };
  await upsertLocalFirst('appointments', record);
  await logActivity(actor, 'appointments', 'تغيير حالة موعد', `${appointment.patientName || ''} - ${status}`);
}

export async function deleteAppointment(appointment: Appointment, actor: ClinicUser | null) {
  await softDeleteLocalFirst('appointments', appointment);
  await logActivity(actor, 'appointments', 'أرشفة موعد', appointment.patientName || appointment.id);
}

export async function listTransactionsForUser(user: ClinicUser) {
  const transactions = (await db.transactions.toArray()).filter((t) => !t.deletedAt);
  if (user.role === 'doctor') {
    return transactions.filter((t) => t.doctorId === user.doctorId || t.doctorId === user.id);
  }
  return transactions;
}

export async function saveTransaction(input: Omit<Transaction, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'> & Partial<Pick<Transaction, 'id' | 'createdAt'>>, actor: ClinicUser | null, writeLog = true) {
  const now = nowIso();
  const record: Transaction = {
    ...input,
    id: input.id || uid('transaction'),
    amount: Number(input.amount) || 0,
    createdAt: input.createdAt || now,
    updatedAt: now,
    deletedAt: null
  };
  await upsertLocalFirst('transactions', record);
  if (writeLog) await logActivity(actor, 'financials', input.id ? 'تعديل حركة مالية' : 'إضافة حركة مالية', `${record.description} - ${record.currency}`);
  return record;
}

export async function deleteTransaction(transaction: Transaction, actor: ClinicUser | null) {
  await softDeleteLocalFirst('transactions', transaction);
  await logActivity(actor, 'financials', 'أرشفة حركة مالية', transaction.description);
}

export async function listEmployees() {
  return (await db.employees.toArray()).filter((e) => !e.deletedAt);
}

export async function saveEmployee(input: Omit<Employee, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'> & Partial<Pick<Employee, 'id' | 'createdAt'>>, actor: ClinicUser | null) {
  const now = nowIso();
  const record: Employee = {
    ...input,
    id: input.id || uid('employee'),
    monthlySalary: Number(input.monthlySalary) || 0,
    active: input.active ?? true,
    createdAt: input.createdAt || now,
    updatedAt: now,
    deletedAt: null
  };
  await upsertLocalFirst('employees', record);
  await logActivity(actor, 'employees', input.id ? 'تعديل موظف' : 'إضافة موظف', record.fullName);
  return record;
}

export async function listInventory() {
  return (await db.inventory.toArray()).filter((i) => !i.deletedAt);
}

export async function saveInventoryItem(input: Omit<InventoryItem, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'> & Partial<Pick<InventoryItem, 'id' | 'createdAt'>>, actor: ClinicUser | null) {
  const now = nowIso();
  const record: InventoryItem = {
    ...input,
    id: input.id || uid('inventory'),
    quantity: Number(input.quantity) || 0,
    minThreshold: Number(input.minThreshold) || 0,
    createdAt: input.createdAt || now,
    updatedAt: now,
    deletedAt: null
  };
  await upsertLocalFirst('inventory', record);
  await logActivity(actor, 'inventory', input.id ? 'تعديل صنف' : 'إضافة صنف', record.name);
  return record;
}

export async function getCurrencySummaries(user: ClinicUser) {
  const currencies: Currency[] = ['YER', 'SAR', 'USD'];
  const [patients, transactions] = await Promise.all([listPatientsForUser(user), listTransactionsForUser(user)]);

  return currencies.map<CurrencySummary>((currency) => {
    const currencyTransactions = transactions.filter((t) => t.currency === currency);
    const income = currencyTransactions
      .filter((t) => ['income', 'payment'].includes(t.type))
      .reduce((sum, t) => sum + t.amount, 0);
    const expenses = currencyTransactions
      .filter((t) => ['expense', 'salary', 'advance', 'commission'].includes(t.type))
      .reduce((sum, t) => sum + t.amount, 0);
    const outstanding = patients.filter((p) => p.currency === currency).reduce((sum, p) => sum + (p.remainingBalance || 0), 0);
    const doctorCommissions = currencyTransactions.filter((t) => t.type === 'commission').reduce((sum, t) => sum + t.amount, 0);
    return {
      currency,
      income,
      expenses,
      netProfit: income - expenses,
      outstanding,
      doctorCommissions
    };
  });
}

export async function restoreRecord(tableName: 'patients' | 'appointments' | 'transactions' | 'employees', id: string, actor: ClinicUser | null) {
  const table = db[tableName] as any;
  const record = await table.get(id);
  if (!record) return;
  const restored = { ...record, deletedAt: null, updatedAt: nowIso() };
  await upsertLocalFirst(tableName, restored);
  await logActivity(actor, 'backup', 'استعادة سجل مؤرشف', `${tableName}: ${id}`);
}
