export type ID = string;

export type UserRole = 'admin' | 'doctor' | 'receptionist' | 'accountant';
export type PermissionLevel = 'full' | 'partial' | 'view' | 'none';
export type Currency = 'YER' | 'SAR' | 'USD';

export type AppModule =
  | 'dashboard'
  | 'patients'
  | 'financials'
  | 'appointments'
  | 'employees'
  | 'inventory'
  | 'reports'
  | 'activityLogs'
  | 'backup'
  | 'settings'
  | 'search';

export type PaymentStatus = 'paid' | 'unpaid';
export type AppointmentStatus = 'scheduled' | 'completed' | 'cancelled' | 'rescheduled';
export type TransactionType = 'income' | 'expense' | 'payment' | 'salary' | 'advance' | 'commission';
export type ExpenseCategory = 'rent' | 'supplies' | 'utilities' | 'equipment' | 'maintenance' | 'marketing' | 'miscellaneous';
export type SyncAction = 'upsert' | 'delete';
export type SyncStatus = 'pending' | 'synced' | 'failed';

export interface PermissionMap {
  patients: PermissionLevel;
  financials: PermissionLevel;
  appointments: PermissionLevel;
  employees: PermissionLevel;
  inventory: PermissionLevel;
  reports: PermissionLevel;
  activityLogs: PermissionLevel;
  backup: PermissionLevel;
  settings: PermissionLevel;
  search: PermissionLevel;
}

export interface BaseRecord {
  id: ID;
  createdAt: string;
  updatedAt: string;
  deletedAt?: string | null;
}

export interface ClinicUser extends BaseRecord {
  fullName: string;
  username: string;
  passwordHash: string;
  role: UserRole;
  doctorId?: ID | null;
  permissions: PermissionMap;
  active: boolean;
  phone?: string;
}

export interface Patient extends BaseRecord {
  fullName: string;
  age: number;
  phone: string;
  assignedDoctorId: ID;
  assignedDoctorName?: string;
  procedureType: string;
  totalCost: number;
  paidAmount: number;
  remainingBalance: number;
  currency: Currency;
  paymentStatus: PaymentStatus;
  treatmentCompleted: boolean;
  notes?: string;
}

export interface Appointment extends BaseRecord {
  patientId: ID;
  patientName?: string;
  doctorId: ID;
  doctorName?: string;
  appointmentAt: string;
  status: AppointmentStatus;
  notes?: string;
}

export interface Transaction extends BaseRecord {
  type: TransactionType;
  currency: Currency;
  amount: number;
  description: string;
  date: string;
  category?: ExpenseCategory | string;
  patientId?: ID;
  doctorId?: ID;
  employeeId?: ID;
}

export interface Employee extends BaseRecord {
  fullName: string;
  jobTitle: string;
  role: UserRole | 'assistant' | 'nurse' | 'other';
  phone?: string;
  monthlySalary: number;
  currency: Currency;
  active: boolean;
}

export interface InventoryItem extends BaseRecord {
  name: string;
  category?: string;
  quantity: number;
  minThreshold: number;
  unit?: string;
  notes?: string;
}

export interface ActivityLog extends BaseRecord {
  actorId?: ID;
  actorName?: string;
  module: AppModule;
  action: string;
  details?: string;
}

export interface SyncQueueItem extends BaseRecord {
  tableName: EntityTableName;
  action: SyncAction;
  payload: unknown;
  status: SyncStatus;
  retries: number;
  lastError?: string;
}

export interface ClinicSetting {
  key: string;
  value: unknown;
  updatedAt: string;
}

export type EntityTableName =
  | 'users'
  | 'patients'
  | 'appointments'
  | 'transactions'
  | 'employees'
  | 'inventory'
  | 'activityLogs'
  | 'settings';

export interface CurrencySummary {
  currency: Currency;
  income: number;
  expenses: number;
  netProfit: number;
  outstanding: number;
  doctorCommissions: number;
}
