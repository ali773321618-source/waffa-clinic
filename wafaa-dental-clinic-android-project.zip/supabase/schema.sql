-- Supabase schema for: عيادة د. وفاء عبدالكريم
-- Column names intentionally match the TypeScript/Dexie camelCase models to avoid fragile mapping code.
-- Run this in Supabase SQL Editor, then add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to .env.

create table if not exists public.users (
  id text primary key,
  "fullName" text not null,
  username text not null unique,
  "passwordHash" text not null,
  role text not null check (role in ('admin','doctor','receptionist','accountant')),
  "doctorId" text,
  permissions jsonb not null default '{}'::jsonb,
  active boolean not null default true,
  phone text,
  "createdAt" timestamptz not null default now(),
  "updatedAt" timestamptz not null default now(),
  "deletedAt" timestamptz
);

create table if not exists public.patients (
  id text primary key,
  "fullName" text not null,
  age integer not null default 0,
  phone text not null,
  "assignedDoctorId" text not null,
  "assignedDoctorName" text,
  "procedureType" text not null,
  "totalCost" numeric not null default 0,
  "paidAmount" numeric not null default 0,
  "remainingBalance" numeric not null default 0,
  currency text not null check (currency in ('YER','SAR','USD')),
  "paymentStatus" text not null check ("paymentStatus" in ('paid','unpaid')),
  "treatmentCompleted" boolean not null default false,
  notes text,
  "createdAt" timestamptz not null default now(),
  "updatedAt" timestamptz not null default now(),
  "deletedAt" timestamptz
);

create table if not exists public.appointments (
  id text primary key,
  "patientId" text not null,
  "patientName" text,
  "doctorId" text not null,
  "doctorName" text,
  "appointmentAt" timestamptz not null,
  status text not null check (status in ('scheduled','completed','cancelled','rescheduled')),
  notes text,
  "createdAt" timestamptz not null default now(),
  "updatedAt" timestamptz not null default now(),
  "deletedAt" timestamptz
);

create table if not exists public.transactions (
  id text primary key,
  type text not null check (type in ('income','expense','payment','salary','advance','commission')),
  currency text not null check (currency in ('YER','SAR','USD')),
  amount numeric not null default 0,
  description text not null,
  date date not null,
  category text,
  "patientId" text,
  "doctorId" text,
  "employeeId" text,
  "createdAt" timestamptz not null default now(),
  "updatedAt" timestamptz not null default now(),
  "deletedAt" timestamptz
);

create table if not exists public.employees (
  id text primary key,
  "fullName" text not null,
  "jobTitle" text not null,
  role text not null,
  phone text,
  "monthlySalary" numeric not null default 0,
  currency text not null check (currency in ('YER','SAR','USD')),
  active boolean not null default true,
  "createdAt" timestamptz not null default now(),
  "updatedAt" timestamptz not null default now(),
  "deletedAt" timestamptz
);

create table if not exists public.inventory (
  id text primary key,
  name text not null,
  category text,
  quantity numeric not null default 0,
  "minThreshold" numeric not null default 0,
  unit text,
  notes text,
  "createdAt" timestamptz not null default now(),
  "updatedAt" timestamptz not null default now(),
  "deletedAt" timestamptz
);

create table if not exists public."activityLogs" (
  id text primary key,
  "actorId" text,
  "actorName" text,
  module text not null,
  action text not null,
  details text,
  "createdAt" timestamptz not null default now(),
  "updatedAt" timestamptz not null default now(),
  "deletedAt" timestamptz
);

create table if not exists public.settings (
  key text primary key,
  value jsonb,
  "updatedAt" timestamptz not null default now()
);

create index if not exists patients_doctor_idx on public.patients ("assignedDoctorId");
create index if not exists patients_phone_idx on public.patients (phone);
create index if not exists appointments_date_idx on public.appointments ("appointmentAt");
create index if not exists appointments_doctor_idx on public.appointments ("doctorId");
create index if not exists transactions_currency_idx on public.transactions (currency);
create index if not exists transactions_date_idx on public.transactions (date);
create index if not exists inventory_low_stock_idx on public.inventory (quantity, "minThreshold");

-- Seed users. Change all passwords from the app after first login.
insert into public.users (id, "fullName", username, "passwordHash", role, "doctorId", permissions, active)
values
('seed_admin', 'مدير النظام', 'admin', '1fff1874b830835a86dd13ea0da556ffbcd416c2fde39bf99bdf9e7df58797ee', 'admin', null, '{"patients":"full","financials":"full","appointments":"full","employees":"full","inventory":"full","reports":"full","activityLogs":"full","backup":"full","settings":"full","search":"full"}', true),
('seed_doctor', 'د. وفاء عبدالكريم', 'doctor', '454627525ed6d8be650a077e66c2b4fad131dd396a572bf4a362a2eab30b5631', 'doctor', 'seed_doctor', '{"patients":"partial","financials":"partial","appointments":"partial","employees":"none","inventory":"view","reports":"none","activityLogs":"none","backup":"none","settings":"none","search":"partial"}', true),
('seed_reception', 'الاستقبال', 'reception', 'e7daa3d121bd8301aec5949d4e125aa7800eb4c967fc3deaff41f2442dd93bd5', 'receptionist', null, '{"patients":"partial","financials":"none","appointments":"partial","employees":"none","inventory":"view","reports":"none","activityLogs":"none","backup":"none","settings":"none","search":"partial"}', true),
('seed_accountant', 'المحاسب', 'accountant', '21c83d7462960cec59037f068bc38c6379787e9cd580bd9e7ec6c6fdd4704b10', 'accountant', null, '{"patients":"view","financials":"full","appointments":"view","employees":"view","inventory":"view","reports":"full","activityLogs":"view","backup":"full","settings":"none","search":"partial"}', true)
on conflict (username) do nothing;

insert into public.settings (key, value)
values ('clinicName', '"عيادة د. وفاء عبدالكريم"'::jsonb)
on conflict (key) do nothing;

-- Realtime support. Idempotent publication registration.
do $$
begin
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='users') then
    alter publication supabase_realtime add table public.users;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='patients') then
    alter publication supabase_realtime add table public.patients;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='appointments') then
    alter publication supabase_realtime add table public.appointments;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='transactions') then
    alter publication supabase_realtime add table public.transactions;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='employees') then
    alter publication supabase_realtime add table public.employees;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='inventory') then
    alter publication supabase_realtime add table public.inventory;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='activityLogs') then
    alter publication supabase_realtime add table public."activityLogs";
  end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='settings') then
    alter publication supabase_realtime add table public.settings;
  end if;
end $$;

-- Security note:
-- This frontend-only build enforces RBAC in the app and filters data locally/offline.
-- For a legally/audited production deployment, put write/read enforcement behind Supabase Auth, RLS with JWT claims,
-- or SECURITY DEFINER RPC functions. Do NOT place a service-role key inside the APK or frontend.
