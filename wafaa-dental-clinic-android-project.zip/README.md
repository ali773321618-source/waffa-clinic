# Arabic Dental Clinic Management & Accounting System

Built for **عيادة د. وفاء عبدالكريم**.

This is a React + Vite + TypeScript + Tailwind Arabic RTL clinic system with offline-first Dexie storage, Supabase sync/realtime hooks, HashRouter APK compatibility, RBAC, patient management, appointments, accounting, inventory, reports, backup/restore, global Arabic search, safe delete, and session auto-lock.

## Tech stack

- React + Vite only
- TypeScript
- Tailwind CSS
- Arabic RTL UI with Cairo font fallback
- HashRouter only, no BrowserRouter
- Supabase Cloud Database + Realtime
- Dexie local database, Version 1 schema only
- Local syncQueue for offline recovery

## Verified build

The project has been compiled successfully with:

```bash
npm install --ignore-scripts
npm run build
```

## Run locally

```bash
npm install
cp .env.example .env
npm run dev
```

Open the local URL shown by Vite.

## Default first-login accounts

Local seed accounts are created only when the local Dexie database is empty:

| Role | Username | Password |
| --- | --- | --- |
| Admin | admin | admin123 |
| Doctor | doctor | doctor123 |
| Reception | reception | reception123 |
| Accountant | accountant | accountant123 |

Change these immediately from **الموظفون والصلاحيات**.

## Supabase setup

1. Create a Supabase project.
2. Open Supabase SQL Editor.
3. Run `supabase/schema.sql`.
4. Copy project URL and anon key into `.env`:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
VITE_CLINIC_NAME=عيادة د. وفاء عبدالكريم
VITE_AUTO_LOCK_MINUTES=15
```

5. Restart Vite.

## Offline behavior

- Online: writes are saved locally and pushed to Supabase.
- Offline: writes are saved in Dexie and placed in `syncQueue`.
- When the device reconnects, pending items are retried automatically.
- Patients, appointments, payments/accounting, inventory, reports, and WhatsApp message generation continue offline.

## Role rules implemented

- Admin: full system access.
- Doctor: own patients, own appointments, own patient financial data, treatment notes. No global profit/salary/expense visibility.
- Receptionist: patients, appointments, WhatsApp reminders. No accounting reports or salaries.
- Accountant: accounting, payments, expenses, payroll, reports, backup.
- Advanced RBAC: Admin can assign Full / Partial / View / No per module.

## Multi-currency accounting

YER, SAR, and USD are intentionally separated. The app does not convert currencies and does not merge them in reports.

## Exports

- Reports: JSON, Excel-compatible `.xls`, print-to-PDF.
- Backup: JSON restore format and Excel-compatible `.xls` review format.

## APK compatibility notes

- The app uses `HashRouter` and `base: './'`, which works reliably inside Android WebViews and APK wrappers.
- Do not replace HashRouter with BrowserRouter.
- Do not hardcode service-role keys in the app.
- For native APK packaging, wrap the built `dist/` using your Android WebView/Capacitor/Cordova pipeline. The web app itself does not require Capacitor as a dependency.

## Production security note

The app includes frontend RBAC and offline role filtering. True database-level enforcement for a medical/accounting system should be added before real-world deployment using Supabase Auth/RLS claims or SECURITY DEFINER RPC functions. This is especially important because a frontend-only custom `users` table login cannot fully protect Supabase rows by itself.

Do not put a Supabase service-role key in `.env`, the APK, or the frontend bundle.
