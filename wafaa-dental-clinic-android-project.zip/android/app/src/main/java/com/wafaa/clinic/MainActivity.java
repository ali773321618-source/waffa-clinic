package com.wafaa.clinic;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
