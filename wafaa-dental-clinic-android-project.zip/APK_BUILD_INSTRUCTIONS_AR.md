# تحويل نظام عيادة د. وفاء عبدالكريم إلى تطبيق Android

تم تجهيز المشروع كتطبيق Android باستخدام Capacitor.

## ما تم إنجازه

- إضافة Capacitor.
- إضافة منصة Android داخل مجلد `android/`.
- ضبط اسم التطبيق: `عيادة د. وفاء عبدالكريم`.
- ضبط Package ID: `com.wafaa.clinic`.
- ربط التطبيق بمجلد البناء `dist`.
- تنفيذ build للواجهة بنجاح.
- نسخ ملفات الويب إلى مشروع Android.

## لتوليد APK على جهازك

1. افتح المشروع في VS Code أو Terminal.
2. نفذ:

```bash
npm install
npm run build
npx cap sync android
npx cap open android
```

3. في Android Studio:

```text
Build > Generate Signed Bundle / APK > APK
```

4. أنشئ keystore واحفظه جيدًا. هذا الملف ضروري لأي تحديث مستقبلي للتطبيق.

## APK تجريبي Debug

من داخل مجلد `android`:

### Windows

```bash
gradlew.bat assembleDebug
```

### macOS / Linux

```bash
./gradlew assembleDebug
```

سيظهر الملف هنا غالبًا:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

## ملاحظة مهمة

لم يتم توليد APK داخل بيئة ChatGPT لأن بيئة التنفيذ هنا لا تحتوي على Android SDK، كما أن تحميل Gradle من `services.gradle.org` غير متاح بسبب قيود الشبكة. المشروع نفسه جاهز للفتح والبناء في Android Studio.
